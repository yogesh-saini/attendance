/**
 * Author: Ravi Tamada
 * URL: www.androidhive.info
 * twitter: http://twitter.com/ravitamada
 * */
package com.deconglobalsolutions.attendance.deconattendance.helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.CallLog;
import android.util.Log;

import java.util.HashMap;

import static android.os.Build.ID;

public class SQLiteHandler extends SQLiteOpenHelper {

	private static final String TAG = SQLiteHandler.class.getSimpleName();
	private Cursor cursor;
	private SQLiteDatabase dataBase = null;
	private ContentValues cValues;
	// All Static variables// Database Version
	public static final int DATABASE_VERSION = 1;
	// Database Name
	public static final String DATABASE_NAME = "Dattendance.sqlite";
	//Table name
	/////////////////////////////////////////////////
	public static final String TABLE_USER 		= "user";
	public static final String TABLE_LOC_DATA 	= "user_loc_data";
	public static final String TABLE_SETTING 	= "setting";
	public static final String TABLE_OFFICE_LOCATION	= "office_location";


	//Table Columns names
	public static final String KEY_ID           			= "id";
	public static final String KEY_NAME         			= "name";
	public static final String KEY_EMAIL        			= "email";
	public static final String KEY_EMP_ID          			= "emp_id";
	public static final String KEY_OFFICE 					= "office";
	public static final String KEY_OFFICE_ADDRESS 			= "office_address";
	public static final String KEY_LATITUDE 	    		= "office_lat";
	public static final String KEY_LONGITUDE  				= "office_lng";
	public static final String KEY_LOCATION 				= "location";
	public static final String KEY_CREATED_AT   			= "created_at";
	public static final String KEY_PASSWORD   				= "password";
	public static final String KEY_RADIUS  					= "radius";
	public static final String KEY_PHONE  					= "phone";
	public static final String KEY_PHONE2  					= "phone2";
	public static final String KEY_IMEI  					= "imei";
	public static final String KEY_IMEI2  					= "imei2";

	public static final String KEY_USERID           		= "userid";
	public static final String KEY_TIME           			= "time";
	public static final String KEY_STATUS           		= "boundary_status";
	public static final String KEY_run_time_ph           	= "run_time_ph";
	public static final String KEY_run_time_im           	= "run_time_im";
	public static final String KEY_run_time_im2           	= "run_time_im2";
	public static final String KEY_run_time_lat           	= "run_time_lat";
	public static final String KEY_run_time_lng           	= "run_time_lng";

	public static final String KEY_USER_ID           		= "id";
	public static final String KEY_CALL_LOG           		= "call";
	public static final String KEY_SMS_LOG           		= "sms";

	public static final String KEY_OFFICE_NAME              = "office_name";
	public static final String KEY_OFFICE_ADD               = "office_add";
	public static final String KEY_OFFICE_LOCATION          = "office_location";
	public static final String KEY_OFFICE_LAT           	= "office_lat";
	public static final String KEY_OFFICE_LNG           	= "office_lng";
	public static final String KEY_OFFICE_ID           	    = "office_id";




	/*public SQLiteHandler(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}*/
	public SQLiteHandler(Context context) {
		super(context, context.getExternalFilesDir(null).getAbsolutePath()
				+ "/" + DATABASE_NAME, null, DATABASE_VERSION);
	}
	@Override
	public void onCreate(SQLiteDatabase db) {
		String CREATE_LOGIN_TABLE = "CREATE TABLE " + TABLE_USER + "("
				+ KEY_ID + " INTEGER PRIMARY KEY," + KEY_NAME + " TEXT,"
				+ KEY_EMAIL + " TEXT UNIQUE," + KEY_PASSWORD + " TEXT,"
				+ KEY_EMP_ID + " TEXT,"+ KEY_OFFICE + " TEXT,"
				+ KEY_OFFICE_ADDRESS + " TEXT,"+ KEY_LATITUDE + " TEXT,"
				+ KEY_LONGITUDE + " TEXT,"+ KEY_LOCATION + " TEXT,"
				+ KEY_CREATED_AT + " TEXT" +")";
		db.execSQL(CREATE_LOGIN_TABLE);

		String CREATE_LOC_DATA = "CREATE TABLE " + TABLE_LOC_DATA + "("
				+ KEY_ID + " INTEGER PRIMARY KEY," + KEY_USERID + " INT," +
				  KEY_STATUS + " nvarchar(30) ," + KEY_run_time_lat + " nvarchar(30),"
				+ KEY_run_time_lng + " nvarchar(30),"+ KEY_TIME + " nvarchar(30),"
				+ KEY_run_time_im + " nvarchar(30),"+ KEY_run_time_im2 + " nvarchar(30),"+ KEY_run_time_ph + " nvarchar(30),"
				+ KEY_CREATED_AT + " TEXT,"+ KEY_OFFICE_ID + " nvarchar(30)" +")";
		db.execSQL(CREATE_LOC_DATA);

		String CREATE_TABLE_SETTING = "CREATE TABLE " + TABLE_SETTING + "("
				+ KEY_ID + " INTEGER PRIMARY KEY," + KEY_SMS_LOG + " TEXT," +
				KEY_CALL_LOG + " TEXT ,"
				+ KEY_CREATED_AT + " TEXT" +")";
		db.execSQL(CREATE_TABLE_SETTING);


		String CREATE_TABLE_OFFICE_LOCATION = "CREATE TABLE " + TABLE_OFFICE_LOCATION + "("
				+ KEY_ID + " INTEGER PRIMARY KEY," + KEY_OFFICE_NAME + "  nvarchar(30)," +
				KEY_OFFICE_ADD + " nvarchar(30) ," + KEY_OFFICE_LOCATION + " nvarchar(30),"
				+ KEY_OFFICE_LAT + " nvarchar(30),"+ KEY_OFFICE_LNG + " nvarchar(30),"+ KEY_OFFICE_ID + " nvarchar(30)" +")";
		db.execSQL(CREATE_TABLE_OFFICE_LOCATION);


		Log.d(TAG, "Database tables created");
	}
	@Override
	  public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// Drop older table if existed

		  db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER );
		  db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOC_DATA );
		  db.execSQL("DROP TABLE IF EXISTS " + TABLE_SETTING );
		  db.execSQL("DROP TABLE IF EXISTS " + TABLE_OFFICE_LOCATION );

		  // Create tables again
		  onCreate(db);

	}
	 public void addUser(String name, String email,String pass, String empid, String office, String off_add,
						 String lat, String lng,String created_at) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_NAME, name); // Name
		values.put(KEY_EMAIL, email); // Email
		values.put(KEY_PASSWORD, pass); // Email
		values.put(KEY_EMP_ID, empid); // Email
		values.put(KEY_OFFICE, office); // Email
		values.put(KEY_OFFICE_ADDRESS, off_add); // Email
		values.put(KEY_LATITUDE, lat); // Email
		values.put(KEY_LONGITUDE, lng); // Email
		 values.put(KEY_CREATED_AT, created_at); // Created At

	/*	values.put(KEY_LOCATION, loc); // Email
	*/
		 long id = db.insert(TABLE_USER, null, values);
		 db.close(); // Closing database connection
		 Log.d(TAG, "New user inserted into sqlite: " + id);
	}

	public HashMap<String, String> getUserDetails() {
		HashMap<String, String> user = new HashMap<String, String>();
		String selectQuery = "SELECT  * FROM " + TABLE_USER;
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		cursor.moveToFirst();
		user.put("email", cursor.getString(1));//2
		user.put("password",cursor.getString(2));//5
			if (cursor.getCount() > 0) {//0
				user.put("name", cursor.getString(3));//1
				user.put("uid", cursor.getString(4));//3
				user.put("created_at", cursor.getString(5));//4
			}
		cursor.close();
		db.close();
		// return user
		Log.d(TAG, "Fetching user from Sqlite: " + user.toString());
		return user;
	}
	public void deleteUsers() {
		SQLiteDatabase db = this.getWritableDatabase();
		// Delete All Rows
		db.delete(TABLE_USER, null, null);
		db.close();
		Log.d(TAG, "Deleted all user info from sqlite");
	}
	public void deleteWorkplan() {
		SQLiteDatabase db = this.getWritableDatabase();
		// Delete All Rows
		db.delete(TABLE_USER, null, null);
		db.close();
		Log.d(TAG, "Deleted all user info from sqlite");
	}
	public Cursor getListContents(){
		SQLiteDatabase db = this.getWritableDatabase();
		Cursor data = db.rawQuery("SELECT * FROM " + TABLE_USER, null);
		return data;
	}
	public Cursor selectRecords() {
		dataBase = this.getWritableDatabase();
		//    Getting data from database table
		cursor = dataBase.rawQuery("select * from " + TABLE_LOC_DATA , null);
		return cursor;
	}



	public void addLocData(String userid,String run_time_lat, String run_time_lng,String boundary_status
						   ,String time,String run_time_ph,String run_time_im1,String run_time_im2,String created_at,String office_id) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_USERID, userid); // Name
	/*	values.put(KEY_PASSWORD, password); // Name*/
	    values.put(KEY_run_time_lat, run_time_lat); // Email
		values.put(KEY_run_time_lng, run_time_lng); // Email
		values.put(KEY_STATUS, boundary_status); // Email
		values.put(KEY_TIME, time); // Email
		values.put(KEY_run_time_ph, run_time_ph); // Email
		values.put(KEY_run_time_im, run_time_im1); // Email
		values.put(KEY_run_time_im2, run_time_im2);
		values.put(KEY_CREATED_AT, created_at); // Created At
        values.put(KEY_OFFICE_ID, office_id);
		long id = db.insert(TABLE_LOC_DATA, null, values);
		db.close(); // Closing database connection
		Log.d(TAG, "New LOC inserted into sqlite: " + id);
	}

 	public HashMap<String, String> getUserDetails1() {
		HashMap<String, String> user = new HashMap<String, String>();
		String selectQuery = "SELECT  * FROM " + TABLE_LOC_DATA;
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		cursor.moveToFirst();
		user.put("userid", cursor.getString(2));
/*
		user.put("password", cursor.getString(2));
*/
		if (cursor.getCount() > 0) {
			user.put("run_time_lat", cursor.getString(1));
			user.put("run_time_lng", cursor.getString(2));
			user.put("time", cursor.getString(3));
			user.put("KEY_run_time_ph", cursor.getString(4));
			user.put("KEY_run_time_im", cursor.getString(5));
			user.put("KEY_run_time_im2", cursor.getString(6));
			user.put("created_at", cursor.getString(7));
		}
		cursor.close();
		db.close();
		// return user
		Log.d(TAG, "Fetching user from Sqlite: " + user.toString());
		return user;
	}


	public Cursor selectCount(String timenow) {
		SQLiteDatabase db = getReadableDatabase();
	//	cursor = db.rawQuery("select count(*) as total from user_loc_data where boundary_status =\""+ status+"\" " ,null);
		cursor =db.rawQuery("select count(*) as total,cast((strftime('%s',\""+timenow+"\" )-strftime('%s',created_at)) AS real)/60 AS min_diff from user_loc_data where date(created_at)=current_date and boundary_status='inside' order by id desc limit 1",null);
		//cursor = db.rawQuery("select count(*) as total from user_loc_data where date(created_at)=current_date and boundary_status ='inside'" ,null);inside
		//cursor.moveToFirst();
		//int count = cursor.getInt(cursor.getColumnIndex("total"));
		//return count;
		//class_tag_id=\"" + classid + "\" and course_id_tag=\"" + course_id + "\" "
		return cursor;
	}


	public Cursor selectCount1(String timenow) {
		SQLiteDatabase db = getReadableDatabase();
		//	cursor = db.rawQuery("select count(*) as total from user_loc_data where boundary_status =\""+ status+"\" " ,null);
		cursor =db.rawQuery("select count(*) as total,cast((strftime('%s',\""+timenow+"\" )-strftime('%s',created_at)) AS real)/60 AS min_diff from user_loc_data where date(created_at)=current_date and boundary_status='outside' order by id desc limit 1",null);
		//cursor = db.rawQuery("select count(*) as total from user_loc_data where date(created_at)=current_date and boundary_status ='inside'" ,null);
		//cursor.moveToFirst();
		//int count = cursor.getInt(cursor.getColumnIndex("total"));
		//return count;
		//class_tag_id=\"" + classid + "\" and course_id_tag=\"" + course_id + "\" "
		return cursor;
	}




	public Cursor counttable_office() {
		SQLiteDatabase db = getReadableDatabase();
		cursor =db.rawQuery("select * from office_location ",null);
		return cursor;
	}
	public void delete_office(){
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(TABLE_OFFICE_LOCATION , null,null);
		db.close();
	}


	public Cursor select_office_id(String lat,String lng) {
		SQLiteDatabase db = getReadableDatabase();
		cursor =db.rawQuery("select count(*) as office_id  from office_location where office_lat=\""+lat+"\" and office_lng=\""+lng+"\"  order by id",null);
		return cursor;
	}


	public Cursor DateCount(String timenow) {
		SQLiteDatabase db = getReadableDatabase();
		//cursor =db.rawQuery("select count(*) as total,cast((strftime('%Y-%m-%d',\""+timenow+"\" )-strftime('%s',created_at)) AS real)/60 AS min_diff from user_loc_data where date(created_at)=current_date and boundary_status='outside' order by id desc limit 1",null);

		cursor =db.rawQuery("select * from user_loc_data where date(created_at)= strftime('%Y-%m-%d',\""+timenow+"\") order by id asc",null);
		//date("+datenow+")
		return cursor;
		//strftime('%Y/%m/%d','now'
	}
	public Cursor DateCount_by_id(String timenow,int id) {
		SQLiteDatabase db = getReadableDatabase();
		//cursor =db.rawQuery("select count(*) as total,cast((strftime('%Y-%m-%d',\""+timenow+"\" )-strftime('%s',created_at)) AS real)/60 AS min_diff from user_loc_data where date(created_at)=current_date and boundary_status='outside' order by id desc limit 1",null);
		//String query = "Select * from "+DB_TABLE+ "Where" +DestStn + "=" + t +"and"+Source + "=" +tt   "=" + bankId
		cursor =db.rawQuery("select * from user_loc_data where date(created_at)= strftime('%Y-%m-%d',\""+timenow+"\") and (id = \""+id+"\") order by id asc",null);
		//date("+datenow+")
		return cursor;
		//strftime('%Y/%m/%d','now'
	}


	public Cursor group_in_out() {
		SQLiteDatabase db = getReadableDatabase();
		cursor = db.rawQuery("SELECT boundary_status,group_concat(created_at,',') AS boundary_time  FROM user_loc_data where date(created_at)=current_date group by boundary_status",null);
		return cursor;

	}

	public void deleteUsers1() {
		SQLiteDatabase db = this.getWritableDatabase();
		// Delete All Rows
		db.delete(TABLE_LOC_DATA, null, null);
		db.close();
		Log.d(TAG, "Deleted all user info from sqlite");
	}
	public void deleteWorkplan1() {
		SQLiteDatabase db = this.getWritableDatabase();
		// Delete All Rows
		db.delete(TABLE_LOC_DATA, null, null);
		db.close();
		Log.d(TAG, "Deleted all user info from sqlite");
	}
	public Cursor getListContents1(){
		SQLiteDatabase db = this.getWritableDatabase();
		Cursor data = db.rawQuery("SELECT * FROM " + TABLE_LOC_DATA, null);
		return data;
	}
	public Cursor selectRecords1() {
		dataBase = this.getWritableDatabase();
		//    Getting data from database table
		cursor = dataBase.rawQuery("select * from " + TABLE_LOC_DATA , null);
		return cursor;
	}
	public Cursor selectRecords_sendsms1() {
		SQLiteDatabase db = getReadableDatabase();
		//    Getting data from database table
		cursor = db.rawQuery("select * from " + TABLE_LOC_DATA ,null);
		return cursor;
	}
	public Cursor selectRecords_setting() {
		SQLiteDatabase db = getReadableDatabase();
		//    Getting data from database table
		cursor = db.rawQuery("select * from " + TABLE_SETTING ,null);
		return cursor;
	}


	public void updateRecord(String userid,String lat, String lng,String time,String boundary_status,String run_time_ph,String run_time_im,String run_time_imei,String created_at) {

		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_USERID, userid);
/*
		values.put(KEY_PASSWORD, password);
*/

		values.put(KEY_run_time_lat, lat);
		values.put(KEY_run_time_lng,lng);
		values.put(KEY_STATUS, boundary_status); // Email
		values.put(KEY_TIME, time); // Email
		values.put(KEY_run_time_ph, run_time_ph); // Email
		values.put(KEY_run_time_im, run_time_im); // Email
		values.put(KEY_run_time_im2, run_time_imei); // Email
		values.put(KEY_CREATED_AT, created_at); // Created At
		 db.update(SQLiteHandler.TABLE_LOC_DATA,values, null,null );
		db.close(); // Closing database connection
		Log.d(TAG, "New LOC inserted into sqlite: " );
	}


	public void addSetting(String call, String sms ) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_CALL_LOG, call); // Name
		values.put(KEY_SMS_LOG, sms); // Email

		long id = db.insert(TABLE_SETTING, null, values);
		db.close(); // Closing database connection
		Log.d(TAG, "New user inserted into sqlite: " + id);
	}


	public HashMap<String, String> getSettingDetails() {
		HashMap<String, String> user = new HashMap<String, String>();
		String selectQuery = "SELECT  * FROM " + TABLE_SETTING;
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		cursor.moveToFirst();
		user.put("email", cursor.getString(2));
		if (cursor.getCount() > 0) {
			user.put("name", cursor.getString(1));
			user.put("uid", cursor.getString(3));
			user.put("created_at", cursor.getString(4));
		}
		cursor.close();
		db.close();
		// return user
		Log.d(TAG, "Fetching user from Sqlite: " + user.toString());
		return user;
	}






	//    Update data from database table
/*
		dataBase.update(DbHelper.TABLE1_NAME, cValues, null, null);
		dataBase.close();
	}
*/

	public void deleteRecord() {
		SQLiteDatabase db = this.getWritableDatabase();
//    Deleting all records from database table
		dataBase.delete(TABLE_LOC_DATA, null, null);
		dataBase.close();
	}



	public void addOfficeAddress(String office_name,String office_add,String office_lat,String office_lng,String office_location,String office_id) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_OFFICE_NAME, office_name);
		values.put(KEY_OFFICE_ADD, office_add);
		values.put(KEY_OFFICE_LAT, office_lat);
		values.put(KEY_OFFICE_LNG, office_lng);
		values.put(KEY_OFFICE_LOCATION, office_location);
		values.put(KEY_OFFICE_ID, office_id);

		long id = db.insert(TABLE_OFFICE_LOCATION, null, values);
		db.close(); // Closing database connection
		Log.d(TAG, "New LOC inserted into sqlite: " + id);
	}


	public void updateRecord(String office_name,String office_add, String office_lat,String office_lng,String office_location) {

		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_OFFICE_NAME, office_name); // Name
		values.put(KEY_OFFICE_ADD, office_add); // Email
		values.put(KEY_OFFICE_LAT, office_lat); // Email
		values.put(KEY_OFFICE_LNG, office_lng); // Email
		values.put(KEY_OFFICE_LOCATION, office_location); // Email
		db.update(SQLiteHandler.TABLE_OFFICE_LOCATION,values, null,null );
		db.close(); // Closing database connection
		Log.d(TAG, "New LOC inserted into sqlite: " );
	}














	/*public Cursor dulicateSetting() {

		dataBase = getReadableDatabase();
		cursor = dataBase.rawQuery("select count(*)  from workplan where id ", null);
		return cursor;


	}*/

	public Cursor dulicateWorkplan(String siteid, String project, String workpackage, String activity) {
		dataBase = getReadableDatabase();
		cursor = dataBase.rawQuery("select count(*)  from workplan where siteid=\""+siteid+"\" and project=\"" + project + "\" and workpackage=\"" + workpackage + "\"  and activity=\"" + activity + "\"  ", null);
		return cursor;
	}

	public Cursor Workplandata(String siteid, String project, String workpackage, String activity) {
		dataBase = getReadableDatabase();
		cursor = dataBase.rawQuery("select id from workplan where siteid=\""+siteid+"\" and project=\"" + project + "\" and workpackage=\"" + workpackage + "\"  and activity=\"" + activity + "\"  ", null);
		return cursor;
	}

   /* public Cursor updateworkplan2(String siteid, String project, String workpackage, String activity,String ptwno,String ptwrejectstatus,String ptw_apprv,String planstaus,String ptw_open_status) {
        *//*SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_PTW_NO						, ptwno);
        values.put(KEY_PTW_NO_REJECT_STATUS			, ptwrejectstatus);
        values.put(KEY_PTW_APPRV_AUDIT_STATUS		, ptw_apprv);
        values.put(KEY_DT_PLAN_STATUS				, planstaus);
        values.put(KEY_DT_PTW_OPEN					, ptw_open_status);

//this.db.update(ENTRY_TABLE, args, ("message = ? AND username = "+user), new String[] {og});
        return db.update(TABLE_WORKPLAN, values, KEY_SITEID + " = ?", new String[]{String.valueOf(siteid)});*//*

        dataBase    = getWritableDatabase();
        cursor      = dataBase.rawQuery("update workplan set ptwno=\""+ptwno+"\", ptw_reject_status=\"" + ptwrejectstatus + "\",ptwApprove_for_audit=\"" + ptw_apprv + "\",dt_planstatus=\"" + planstaus + "\",ptw_open_close=\"" + ptw_open_status + "\"  where siteid=\""+siteid+"\" and project=\"" + project + "\" and workpackage=\"" + workpackage + "\"  and activity=\"" + activity + "\"  ", null);
        return cursor;
    }
*/


	public Cursor Approve_for_audit(String siteid) {
		dataBase = getReadableDatabase();
		cursor = dataBase.rawQuery("select count(*)  from workplan where siteid=\""+siteid+"\" and ptwApprove_for_audit=\"Approve\" and dt_planstatus=\"Not Reject\" and ptw_open_close=\"Open\" ", null);
		return cursor;
	}

	public Cursor ptw_auth(String siteid) {
		dataBase = getReadableDatabase();
		//cursor = dataBase.rawQuery("select count(*)  from workplan where siteid=\""+siteid+"\" and ptw=\"done\" ", null);
		//cursor = dataBase.rawQuery("select count(*)  from workplan where siteid=\""+siteid+"\" and dt_planstatus=\"Not Reject\" and ptw_open_close=\"CLose\" ", null);
		// enter user to FOR PTW
		cursor = dataBase.rawQuery("select count(*)  from workplan where siteid=\""+siteid+"\" and dt_planstatus=\"Not Reject\" and (ptw_open_close=\"CLose\" or ptw_open_close=\"Close\" or ptw_open_close=\"close\" or ptw_reject_status=\"" + "" + "\") ", null);
		return cursor;
	}
	public int ptw_auth2(String siteid) {
		dataBase = getReadableDatabase();
		//select count(*)  from workplan where siteid="Test Site 4" and dt_planstatus="Not Reject" and ptw_open_close="Open"  and (ptw_reject_status="Not Reject" or ptw_reject_status="")
		cursor = dataBase.rawQuery("select count(*)  from workplan where siteid=\""+siteid+"\" and dt_planstatus=\"Not Reject\" and ptw_open_close=\"Open\"  and (ptw_reject_status=\"Not Reject\" or ptw_reject_status=\""+""+"\") ", null);
		cursor.moveToFirst();
		int ptw_auht2    =  cursor.getInt(cursor.getColumnIndex("count(*)"));
		return ptw_auht2;
	}

	public int ptw_auth3(String siteid) {
		dataBase = getReadableDatabase();
		//select count(*)  from workplan where siteid="Test Site 4" and dt_planstatus="Not Reject" and ptw_open_close="Open"  and (ptw_reject_status="Not Reject" or ptw_reject_status="")
		cursor = dataBase.rawQuery("select count(*)  from workplan where siteid=\""+siteid+"\" and dt_planstatus=\"Not Reject\" and ptw_open_close=\"Open\"  and ptw_reject_status=\"Reject\"  ", null);
		cursor.moveToFirst();
		int ptw_auht2    =  cursor.getInt(cursor.getColumnIndex("count(*)"));
		return ptw_auht2;
	}
	public int ptw_auth1(String siteid) {
		dataBase = getReadableDatabase();
		cursor = dataBase.rawQuery("select count(*)  from workplan where siteid=\""+siteid+"\" and dt_planstatus=\"Reject\" ", null);
		cursor.moveToFirst();
		int ptw_auht1    =  cursor.getInt(cursor.getColumnIndex("count(*)"));
		return ptw_auht1;
	}

	public int updateSett(String call, String sms) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_SMS_LOG, sms);
		values.put(KEY_CALL_LOG, call);
		return db.update(TABLE_SETTING, values, KEY_ID + " = ?", new String[]{String.valueOf("1")});
	}
	/*public int updatePTWNO(String site, String ptwno) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_PTW_NO, ptwno);
		return db.update(TABLE_WORKPLAN, values, KEY_SITEID + " = ?", new String[]{String.valueOf(site)});
	}*/

	public int updatename(String name, String email) {
		SQLiteDatabase db 		= this.getWritableDatabase();
		ContentValues values 	= new ContentValues();
		values.put(KEY_NAME, name);
		return db.update(TABLE_USER, values, KEY_EMAIL + " = ?", new String[]{String.valueOf(email)});
	}

	public static Cursor selectRecords_startstatus() {
		return null;
	}

	public static Cursor selectRecords_endstatus() {
	return null;
	}

	public static Cursor selectRecords_continuestatus() {
		return null;
	}





/*
	public void deleteRecord() {
		SQLiteDatabase db = this.getWritableDatabase();
//    Deleting all records from database table
		dataBase.delete(TABLE_LOC_DATA, null, null);
		dataBase.close();
	}

*/


	/*public int updateShop(String site,String status) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_PTW, status);
		return db.update(TABLE_WORKPLAN, values, KEY_SITEID + " = ?", new String[]{String.valueOf(site)});
	}
	public int updateAuditStatus(String site,String status) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_AUDIT, status);
		return db.update(TABLE_WORKPLAN, values, KEY_SITEID + " = ?", new String[]{String.valueOf(site)});
	}*/

    /*public int updateworkplan2(String id,String ptwno,String ptwrejectstatus,String ptw_apprv,String planstaus,String ptw_open_status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
		values.put(KEY_PTW_NO						, ptwno);
		values.put(KEY_PTW_NO_REJECT_STATUS			, ptwrejectstatus);
		values.put(KEY_PTW_APPRV_AUDIT_STATUS		, ptw_apprv);
		values.put(KEY_DT_PLAN_STATUS				, planstaus);
		values.put(KEY_DT_PTW_OPEN					, ptw_open_status);


		return db.update(TABLE_WORKPLAN, values, KEY_ID + " = ?", new String[]{String.valueOf(id)});
    }
*/

	/*public int updateworkplan2(String id, String ptwno, String ptwrejectstatus, String ptw_apprv, String planstaus, String ptw_open_status, String lat, String lng) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_PTW_NO						, ptwno);
		values.put(KEY_PTW_NO_REJECT_STATUS			, ptwrejectstatus);
		values.put(KEY_PTW_APPRV_AUDIT_STATUS		, ptw_apprv);
		values.put(KEY_DT_PLAN_STATUS				, planstaus);
		values.put(KEY_DT_PTW_OPEN					, ptw_open_status);
		values.put(KEY_LATITUDE						, lat);
		values.put(KEY_LONGITUDE					, lng);

		return db.update(TABLE_WORKPLAN, values, KEY_ID + " = ?", new String[]{String.valueOf(id)});
	}*/


	/*public void deleteShop(String site) {
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(TABLE_WORKPLAN, KEY_SITEID + " = ?", new String[] { String.valueOf(site) });
		db.close();
	}*/

}







