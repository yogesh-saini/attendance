package com.deconglobalsolutions.attendance.deconattendance.helper;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ListAdapter;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import static com.deconglobalsolutions.attendance.deconattendance.app.AppConfig.URL_CURRENT_LOCATION;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

import android.location.Location;

import static com.deconglobalsolutions.attendance.deconattendance.app.AppConfig.URL_LOCATION;
import static com.deconglobalsolutions.attendance.deconattendance.app.AppConfig.URL_LOGIN;


public class SendService extends Service implements
        GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, com.google.android.gms.location.LocationListener {
    public static final long NOTIFY_INTERVAL = 60 * 60 * 1000;//20 * 60 * 1000; // 10 seconds
    private Handler mHandler = new Handler();
    private Timer mTimer = null;
    ///   public static String URI = "http://203.122.21.147/mac.php";
    public static String URI = "http://203.122.21.147/mac.php";
    protected static final String TAG = "LocationUpdateService";
    public static final long UPDATE_INTERVAL_IN_MILLISECONDS = 10 * 30 * 1000;
    public static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = UPDATE_INTERVAL_IN_MILLISECONDS;
    protected final static String REQUESTING_LOCATION_UPDATES_KEY = "requesting-location-updates-key";
    protected final static String LOCATION_KEY = "location-key";
    protected final static String LAST_UPDATED_TIME_STRING_KEY = "last-updated-time-string-key";
    public static Boolean mRequestingLocationUpdates;
    protected String mLastUpdateTime;
    protected GoogleApiClient mGoogleApiClient;
    protected LocationRequest mLocationRequest;
    protected Location mCurrentLocation;
    public static boolean isEnded = false;
    private Button btnInsert, btnUpdate, btnSelect, btnDelete;
    private SQLiteHandler sqLiteHandler1;
    private Cursor cursor, cursor3, cursor4, cur;
    private String unique_id, celllocation, simoperator, simserial, linenumber, status_start, dated_start, status_end, dated_end;
    protected String useremail, password;

    private final static int CONNECTION_FAILURE_RESOLUTION_REQUEST = 9000;

    private GoogleApiClient GoogleApiClient;
    private LocationRequest LocationRequest;
    private double currentLatitude;
    private double currentLongitude;


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        if (mTimer != null) {
            mTimer.cancel();
        } else {
            mTimer = new Timer();
        }
        mTimer.scheduleAtFixedRate(new TimeDisplayTimerTask(), 0, NOTIFY_INTERVAL);
        sqLiteHandler1 = new SQLiteHandler(getApplicationContext());
        cursor = sqLiteHandler1.getListContents();
        cursor.moveToFirst();
        useremail = getimei();
       // useremail = cursor.getString(2);
       // password = cursor.getString(3);
    }
    public String getimei(){
        TelephonyManager telephonyManager = (TelephonyManager) getApplication().getSystemService(Context.TELEPHONY_SERVICE);
        if (ActivityCompat.checkSelfPermission(getApplication(), Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            return "";
        }

        String deviceId1 = telephonyManager.getDeviceId(1).trim();
        // String deviceId2 = telephonyManager.getDeviceId(2).trim();
        return deviceId1;
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("LOC", "Service init...");
        isEnded = false;
        mRequestingLocationUpdates = false;
        mLastUpdateTime = "";
        buildGoogleApiClient();
        if (mGoogleApiClient.isConnected() && mRequestingLocationUpdates) {
            startLocationUpdates();
            mTimer = new Timer();
            mTimer.scheduleAtFixedRate(new TimeDisplayTimerTask(), 0, NOTIFY_INTERVAL);
        }
        return Service.START_REDELIVER_INTENT;
    }

    @Override
    public void onConnected(Bundle bundle) {
        startLocationUpdates();
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.i(TAG, "Connection suspended==");
        mGoogleApiClient.connect();
    }

    public void onLocationChanged(Location location) {
        mCurrentLocation = location;
        mLastUpdateTime = DateFormat.getTimeInstance().format(new Date());
        startLocationUpdates();
        //updateUI();
        // Toast.makeText(this, getResources().getString(R.string.location_updated_message), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.i(TAG, "Connection failed: ConnectionResult.getErrorCode() = " + connectionResult.getErrorCode());
    }


    protected synchronized void buildGoogleApiClient() {
        Log.i(TAG, "Building GoogleApiClient===");
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        createLocationRequest();
    }

    protected void createLocationRequest() {
        mGoogleApiClient.connect();
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(UPDATE_INTERVAL_IN_MILLISECONDS);
        mLocationRequest.setFastestInterval(FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    protected void startLocationUpdates() {
        if (!mRequestingLocationUpdates) {
            mRequestingLocationUpdates = true;
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            LocationServices.FusedLocationApi.requestLocationUpdates(
                    mGoogleApiClient, mLocationRequest, (com.google.android.gms.location.LocationListener) this);
            // Log.i(TAG, " startLocationUpdates===");
            isEnded = true;
        }
    }

    /**
     * Removes location updates from the FusedLocationApi.
     */
    protected void stopLocationUpdates() {
        if (mRequestingLocationUpdates) {
            mRequestingLocationUpdates = false;
            //Log.d(TAG, "stopLocationUpdates();==");
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, (com.google.android.gms.location.LocationListener) this);
        }
    }


    public void onStatusChanged(String s, int i, Bundle bundle) {

    }


    public void onProviderEnabled(String s) {

    }

    public void onProviderDisabled(String s) {

    }


    public class TimeDisplayTimerTask extends TimerTask {
        @Override
        public void run() {
            boolean post = mHandler.post(new Runnable() {
                @Override
                public void run() {
                    //new AsyncSender().execute();
                    //Toast.makeText(getApplicationContext(),"abc",Toast.LENGTH_LONG).show();

                    //cursor.moveToFirst();
                    Cursor data = sqLiteHandler1.selectRecords();
                    if (data.moveToFirst()) {
                        do {
                            String status = data.getString(2);
                            String lat = data.getString(3);
                            String lng = data.getString(4);
                            String time = data.getString(9);
                            String im = data.getString(6);
                            String im2 = data.getString(7);
                            String office_id = data.getString(10);

                           /* Cursor cur = sqLiteHandler1.selectOfficeRecords();
                            cur.moveToFirst();
                            String office_id =cur.getString(6);*/
                            Log.i("top_check", status + " " + lat + " " + lng + " " + time + " " + im + " " + im2 + " " + office_id + "\n");
                            sendserverdetail(useremail, /*password,*/ status, lat, lng, time, im, im2, office_id);
                            //Log.i("status_check", String.valueOf(currentLatitude) + String.valueOf(currentLongitude));

                            try {
                                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                    return;
                                }
                                Location mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
                                if (mLastLocation != null) {
                                    TelephonyManager tManager = (TelephonyManager) getBaseContext().getSystemService(Context.TELEPHONY_SERVICE);
                                    String lat1 = Double.toString(mLastLocation.getLatitude());
                                    String lng1 = Double.toString(mLastLocation.getLongitude());

                                    Calendar cal = Calendar.getInstance();
                                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                    df.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
                                    String timenow = df.format(cal.getTime());


                                    Log.i("status_check", String.valueOf(lat1) + String.valueOf(lng1) +"  " +String.valueOf(timenow));

                                    sendcurrentlatlng(useremail, /*password,*/ String.valueOf(lat1), String.valueOf(lng1),timenow);
                                }
                            }catch (Exception e){
                                Log.i("error","something wrong");
                            }



                        } while (data.moveToNext());
                   }

                    data.close();
                }
            });
        }
    }
       private void sendcurrentlatlng( final String userid, /*final String pass,*/
                                      final String lat, final String lng,final String timenow ) {

           StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_CURRENT_LOCATION,
                   new Response.Listener<String>() {

                       @Override
                       public void onResponse(String response) {
                           //Log.i("dat_check",response);

                       //    Toast.makeText(getApplicationContext(), response , Toast.LENGTH_LONG).show();
                       }
                   },
                   new Response.ErrorListener() {
                       @Override
                       public void onErrorResponse(VolleyError error) {
                           if (error instanceof NetworkError) {
                           } else if (error instanceof ServerError) {
                           } else if (error instanceof AuthFailureError) {
                           } else if (error instanceof ParseError) {
                           } else if (error instanceof NoConnectionError) {
                           } else if (error instanceof TimeoutError) {
                               Toast.makeText(getApplicationContext(),
                                       "Oops. Timeout error!",Toast.LENGTH_SHORT).show();
                               //  Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                           }
                       }
                   }) {
               @Override
               protected Map<String, String> getParams() throws AuthFailureError {
                   Map<String, String> map = new HashMap<String, String>();
                   map.put("email", userid);
                   //map.put("password",pass);
                   map.put("lat", lat);
                   map.put("lng", lng);
                   map.put("time_check", timenow);
                   return map;
               }
           };
           RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
           requestQueue.add(stringRequest);
       }

    private void sendserverdetail(final String userid,/*final String pass, */final String status,
                                  final String lat, final String lng, final String time, final String im,
                                  final String im2, final String office_id) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_LOCATION,
                new Response.Listener<String>() {

                  @Override
                    public void onResponse(String response) {
                      //Log.i("dat_check",response);

                     // Toast.makeText(getApplicationContext(), response , Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (error instanceof NetworkError) {
                        } else if (error instanceof ServerError) {
                        } else if (error instanceof AuthFailureError) {
                        } else if (error instanceof ParseError) {
                        } else if (error instanceof NoConnectionError) {
                        } else if (error instanceof TimeoutError) {
                            Toast.makeText(getApplicationContext(),
                                    "Oops. Timeout error!",Toast.LENGTH_SHORT).show();
                      //  Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                        }
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<String, String>();
                map.put("email", userid);
                //map.put("password",pass);
                map.put("lat", lat);
                map.put("lng", lng);
                map.put("status", status);
                map.put("time", time);
                map.put("imei1", im);
                map.put("imei2", im2);
                map.put("office_id", office_id);
                return map;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }
    public String send_start(){
        cursor3                 =   sqLiteHandler1.selectRecords_startstatus();
        cursor3.moveToFirst();
        if(cursor3.getCount()>0) {
            String status_start = cursor3.getString(cursor3.getColumnIndex(SQLiteHandler.KEY_STATUS));
            String dated_start = cursor3.getString(cursor3.getColumnIndex(SQLiteHandler.KEY_TIME));
            Log.i("start", status_start + dated_start);
            return dated_start;
        }
        else {
            return null;
        }
    }
    public String send_end(){
        cursor4                 =   sqLiteHandler1.selectRecords_endstatus();
        cursor4.moveToFirst();
        if(cursor4.getCount()>0) {
            String status_end = cursor4.getString(cursor4.getColumnIndex(SQLiteHandler.KEY_STATUS));
            String dated_end = cursor4.getString(cursor4.getColumnIndex(SQLiteHandler.KEY_TIME));
            Log.i("end", dated_end + status_end);
            return dated_end;
        }
        else {
            return null;
        }
    }

    private String getSimSN(TelephonyManager tm, String failMsg) {
        if (tm == null) { tm = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE); }
        String sn = failMsg;
        if (tm != null) {
            int state = tm.getSimState();
            if (state == TelephonyManager.SIM_STATE_ABSENT) { sn = "No SIM"; }
            else if (state == TelephonyManager.SIM_STATE_READY) {
                @SuppressLint("MissingPermission") String realSN = tm.getSimSerialNumber();
                if (realSN != null) { sn = realSN; }
            }
        }
        return sn;
    }

    public static boolean isInternetWorking() {
        boolean success = false;
        try {
            URL url = new URL("https://google.com");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(10000);
            connection.connect();
            success = connection.getResponseCode() == 200;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mTimer = new Timer();
        mTimer.scheduleAtFixedRate(new TimeDisplayTimerTask(), 0, NOTIFY_INTERVAL);
    }
}
