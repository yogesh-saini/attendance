package com.deconglobalsolutions.attendance.deconattendance;

import android.content.Context;
import android.telephony.TelephonyManager;

import java.util.ArrayList;

/**
 * Created by ngodung on 10/11/17.
 */

public class IMEIUtil {


    //public static String getDeviceId(Context context) {
    public static String[] getDeviceId(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        String deviceId = telephonyManager.getDeviceId().trim();
        String sim_op  = telephonyManager.getSimOperatorName().trim();
        String sim_st = telephonyManager.getSimSerialNumber().trim();
        String sim_ = telephonyManager.getLine1Number().trim();

        ArrayList<String> newarray = new ArrayList<String>(4);


        newarray.add(deviceId);
        newarray.add(sim_op);
        newarray.add(sim_st);
        newarray.add(sim_);
        String[] A = {deviceId,sim_op,sim_st,sim_};
        /*
        if (deviceId == null) {
            String androidId = Settings.Secure.getString(context.getContentResolver(),
                    Settings.Secure.ANDROID_ID);
            deviceId = android.os.Build.SERIAL + "#" + androidId;
        }*/
      ///  return deviceId.trim();
    return A;
    }
/*
    public ArrayList<String> getDeviceId() {
        return deviceId;
        ArrayList<String> deviceId1;
        return deviceId1;
    }

    public void setDeviceId(ArrayList<String> deviceId) {
        this.deviceId = deviceId;*/




    }






