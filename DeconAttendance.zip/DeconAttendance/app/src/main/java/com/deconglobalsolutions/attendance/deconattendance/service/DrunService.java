package com.deconglobalsolutions.attendance.deconattendance.service;

import android.Manifest;
import android.app.ActivityManager;
import android.app.IntentService;
import android.app.ProgressDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.telephony.TelephonyManager;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import com.deconglobalsolutions.attendance.deconattendance.app.AppConfig;
import com.deconglobalsolutions.attendance.deconattendance.app.AppController;
import com.deconglobalsolutions.attendance.deconattendance.helper.SQLiteHandler;
import com.deconglobalsolutions.attendance.deconattendance.helper.SessionManager;

import static com.deconglobalsolutions.attendance.deconattendance.app.AppController.TAG;

/**
 * Created by Narender on 7/24/2017.
 */

public class DrunService extends IntentService {

    public static final long NOTIFY_INTERVAL = 30 * 1000; // 10 seconds
    private Handler mHandler = new Handler();
    private Timer mTimer = null;
    public static final long UPDATE_INTERVAL_IN_MILLISECONDS = 30000;
    public static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = UPDATE_INTERVAL_IN_MILLISECONDS;
    protected final static String REQUESTING_LOCATION_UPDATES_KEY = "requesting-location-updates-key";
    private SQLiteHandler db;
    private ProgressDialog pDialog;
    private String ptwno, ptw_apprv, ptwrejectstatus, lat, lng, ptw_open_status;
    private Cursor cursor;
    private long diff, diffSeconds, diffMinutes, diffHours, diffDays;
    private SessionManager session;

    public DrunService() {
        super(TAG);
    }

    @Nullable
   /* @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
*/
    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

    }

    @Override
    public void onCreate() {
        if (mTimer != null) {
            mTimer.cancel();
        } else {
            mTimer = new Timer();
        }
        mTimer.scheduleAtFixedRate(new TimeDisplayTimerTask(), 0, NOTIFY_INTERVAL);
        db = new SQLiteHandler(getApplicationContext());
    }

    class TimeDisplayTimerTask extends TimerTask {
        @Override
        public void run() {
            boolean post = mHandler.post(new Runnable() {
                @Override
                public void run() {
                    HashMap<String, String> user = db.getUserDetails();
                    String password = user.get("uid");
                    String email = user.get("email");
                    String created_at = user.get("created_at");
                    TelephonyManager tManager = (TelephonyManager) getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
                    if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                        return;
                    }
                    String imei = tManager.getDeviceId().toString();
                    askAuth(email,password,imei);
                }
            });
        }
    }

    private void askAuth(final String email, final String password, final String imei) {
        String tag_string_req = "req_login";
        StringRequest strReq = new StringRequest(Request.Method.POST, AppConfig.URL_LOGIN, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jObj = new JSONObject(response);
                    JSONArray contacts = jObj.getJSONArray("data");
                    if (contacts != null && contacts.length() > 0) {
                        for (int i = 0; i < contacts.length(); i++) {
                            JSONObject c            = contacts.getJSONObject(i);

                            String id               = c.getString("id");
                            String date             = c.getString("Date");
                            String emp              = c.getString("Emp");
                            String project          = c.getString("Project");
                            String siteid           = c.getString("SiteId");
                            String workpackage      = c.getString("WorkPackage");
                            String activity         = c.getString("Activity");
                            String alot_by          = c.getString("AllotBy");

                            JSONArray latlongimfo  = c.getJSONArray("latlongimfo");
                            if (latlongimfo != null && latlongimfo.length() > 0) {
                                JSONObject d        = latlongimfo.getJSONObject(latlongimfo.length()-1);
                                lat                = d.getString("latitude");
                                lng                = d.getString("longitude");
                            }else{
                                lat                 = "";
                                lng                 = "";
                            }

                            JSONArray approvalinfo  = c.getJSONArray("Approvalinfo");
                            if (approvalinfo != null && approvalinfo.length() > 0) {

                                JSONObject e        = approvalinfo.getJSONObject(approvalinfo.length()-1);
                                ptwno               = e.getString("PTWNo");
                                ptwrejectstatus     = e.getString("PTWRejectStatus");
                                ptw_apprv           = e.getString("ApproveStatus");
                                ptw_open_status     = e.getString("status");
                            }else{
                                ptwno               = "";
                                ptwrejectstatus     = "";
                                ptw_apprv           = "";
                                ptw_open_status     = "";
                            }
                            String planstaus        = c.getString("planrejectstatus");
                            //Toast.makeText(getApplicationContext(),date + " "+ project + " " + siteid + " " + workpackage + " " + activity+ " " + emp+ " " + lat+ " " + lng+ " " + ptwno+ " " +ptwrejectstatus + " " + ptw_apprv+ " " + planstaus+ " " + ptw_open_status  , Toast.LENGTH_LONG).show();
                            //Toast.makeText(getApplicationContext(),date + " "+  siteid+" "+ ptwno+ " " +ptwrejectstatus + " " + ptw_apprv+ " " + planstaus+ " " + ptw_open_status  , Toast.LENGTH_LONG).show();
                           /* Toast toast = Toast.makeText(getApplicationContext(), date + " "+  siteid+" "+ ptwno+ " " +ptwrejectstatus + " " + ptw_apprv+ " " + planstaus+ " " + ptw_open_status , Toast.LENGTH_LONG);
                            toast.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL, 0, 0);
                            View vieew = toast.getView();vieew.setBackgroundColor(Color.parseColor("#BD8BDC"));
                            vieew.setBackgroundResource(R.drawable.textinputborder);toast.setView(vieew);toast.show();*/
                            cursor                  = db.dulicateWorkplan(siteid, project, workpackage, activity);cursor.moveToFirst();
                            int dupPlan             = cursor.getInt(cursor.getColumnIndex("count(*)"));
                            if(dupPlan==0) {
                                //db.addWorkplan(siteid,project,workpackage, lat, lng, date,activity,ptwno,ptwrejectstatus,ptw_apprv,planstaus,ptw_open_status);
                                db.updatename(emp,email);
                            }else {
                                cursor              =   db.Workplandata( siteid,  project,  workpackage,  activity);
                                cursor.moveToFirst();
                                String id1         =   cursor.getString(cursor.getColumnIndex("id"));
                                //Toast.makeText(getApplicationContext(),id1+planstaus,Toast.LENGTH_LONG).show();
                                //  db.updateworkplan2(id1, ptwno, ptwrejectstatus, ptw_apprv, planstaus, ptw_open_status,lat,lng);
                            }
                           // db.updatename(emp,email);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Error In Downloading Data From Server", Toast.LENGTH_LONG).show();
                    /*Toast.makeText(getApplicationContext(), "Json error: " + e.getMessage(), Toast.LENGTH_LONG).show();*/
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
               // Toast.makeText(getApplicationContext(), "Connection to server is unreachable", Toast.LENGTH_LONG).show();
                //hideDialog();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("email"      , email);
                params.put("password"   , password);
                params.put("imei"       , imei);
                return params;
            }
        };
        AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
    }


    private long diff_time(String datePast, String dateToday){
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date d1 = null;
        Date d2 = null;
        try {
            d1 				= format.parse(datePast);
            d2 				= format.parse(dateToday);
            diff           	= d2.getTime() - d1.getTime();
            diffSeconds    	= diff / 1000 % 60;
            diffMinutes    	= diff / (60 * 1000) % 60;
            diffHours      	= diff / (60 * 60 * 1000) % 24;
            diffDays       	= diff / (24 * 60 * 60 * 1000);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return diffHours;
    }
    private long diff_day(String datePast, String dateToday){
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date d1 = null;
        Date d2 = null;
        try {
            d1 				= format.parse(datePast);
            d2 				= format.parse(dateToday);
            diff           	= d2.getTime() - d1.getTime();
            diffSeconds    	= diff / 1000 % 60;
            diffMinutes    	= diff / (60 * 1000) % 60;
            diffHours      	= diff / (60 * 60 * 1000) % 24;
            diffDays       	= diff / (24 * 60 * 60 * 1000);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return diffDays;
    }

    private void logoutUser() {
        session.setLogin(false);
        db.deleteUsers();
        db.deleteWorkplan();
    }
    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }


}


