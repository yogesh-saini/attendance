package com.deconglobalsolutions.attendance.deconattendance;

import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.TextView;

/**
 * Created by Narender Rathore on 5/9/2017.
 */

public class myPhoneStateListener extends PhoneStateListener {
    public int signalStrengthValue;
    TelephonyManager telephonyManager;
    myPhoneStateListener psListener;
    TextView txtSignalStr;

    public void onSignalStrengthsChanged(SignalStrength signalStrength) {
        super.onSignalStrengthsChanged(signalStrength);
        if (signalStrength.isGsm()) {
            if (signalStrength.getGsmSignalStrength() != 99)
                signalStrengthValue = signalStrength.getGsmSignalStrength() * 2 - 113;
            else
                signalStrengthValue = signalStrength.getGsmSignalStrength();
        } else {
            signalStrengthValue = signalStrength.getCdmaDbm();
        }
        Log.i("Signal", String.valueOf(signalStrengthValue));
      //  txtSignalStr.setText("Signal Strength : " + signalStrengthValue);
    }


}