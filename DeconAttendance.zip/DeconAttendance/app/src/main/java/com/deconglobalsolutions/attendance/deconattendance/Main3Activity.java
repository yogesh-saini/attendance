package com.deconglobalsolutions.attendance.deconattendance;

import android.database.Cursor;
import android.graphics.Color;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.deconglobalsolutions.attendance.deconattendance.helper.SQLiteHandler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.TimeZone;

import devs.mulham.horizontalcalendar.HorizontalCalendar;
import devs.mulham.horizontalcalendar.model.CalendarEvent;
import devs.mulham.horizontalcalendar.utils.CalendarEventsPredicate;
import devs.mulham.horizontalcalendar.utils.HorizontalCalendarListener;

import static com.deconglobalsolutions.attendance.deconattendance.helper.SQLiteHandler.KEY_USERID;

public class Main3Activity extends AppCompatActivity {
    private HorizontalCalendar horizontalCalendar;
    private long temp;
    private long total_min;
    private SQLiteHandler db;
   // private Calendar date1;
private Date date1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        setTitle("status");
        db = new SQLiteHandler(getApplicationContext());
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        /* start 2 months ago from now */
        Calendar startDate = Calendar.getInstance();
        startDate.add(Calendar.MONTH, -2);
        /* end after 2 months from now */
        Calendar endDate = Calendar.getInstance();
        endDate.add(Calendar.MONTH, 2);
        // Default Date set to Today.

        final Calendar defaultSelectedDate = Calendar.getInstance();
            horizontalCalendar = new HorizontalCalendar.Builder(this, R.id.calendarView)
                        .range(startDate, endDate)
                        .datesNumberOnScreen(5)
                        .configure()
                        .formatTopText("MMM")
                        .formatMiddleText("dd")
                        .formatBottomText("EEE")
                        .showTopText(true)
                        .showBottomText(true)
                        .textColor(Color.LTGRAY, Color.WHITE)
                        .colorTextMiddle(Color.LTGRAY, Color.parseColor("#ffd54f"))
                        .end()
                        .defaultSelectedDate(defaultSelectedDate)
                        .addEvents(new CalendarEventsPredicate() {
                            Random rnd = new Random();
                            @Override
                            public List<CalendarEvent> events(Calendar date) {
                                List<CalendarEvent> events = new ArrayList<>();
                           /*      int count = rnd.nextInt(6);

                                for (int i = 0; i <= count; i++){
                                    events.add(new CalendarEvent(Color.rgb(rnd.nextInt(120), rnd.nextInt(1), rnd.nextInt(11)), "event"));
                                }
                           */     return events;
                            }
                        })
                        .build();
                                Log.i("Default Date", DateFormat.format("EEE, MMM d, yyyy", defaultSelectedDate).toString());
                                horizontalCalendar.setCalendarListener(new HorizontalCalendarListener() {
                                    @Override
                                    public void onDateSelected(Calendar date, int position) {
                                        temp = 0;
                                        String selectedDat = DateFormat.format("yyyy-MM-dd", date).toString();
                                        Log.i("cal_time", selectedDat);

                                        Cursor data = db.DateCount(selectedDat);
                                        for (data.moveToFirst(); !data.isAfterLast(); data.moveToNext()) {
                                            final String status = data.getString(data.getColumnIndex(SQLiteHandler.KEY_STATUS)).trim();
                                            final String created_at = data.getString(data.getColumnIndex(SQLiteHandler.KEY_CREATED_AT)).trim();
                                            final String id = String.valueOf(data.getString(data.getColumnIndex(SQLiteHandler.KEY_ID)));
                                            Cursor data2 = db.DateCount_by_id(selectedDat, Integer.parseInt(id) + 1);
                                            if (data2 != null && data2.moveToFirst()) {
                                                final String next_status = String.valueOf(data2.getString(data2.getColumnIndex(SQLiteHandler.KEY_STATUS))).trim();
                                                final String next_created = data2.getString(data2.getColumnIndex(SQLiteHandler.KEY_CREATED_AT)).trim();
                                                Log.i("data2", status + ":" + created_at + ":" + next_created);
                                                //if (next_status.trim().equals("outside")) {
                                                if (status.trim().equals("inside")) {
                                                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                                    Date date1 = null;
                                                    try {
                                                        date1 = format.parse(created_at);
                                                    } catch (ParseException e) {
                                                        e.printStackTrace();
                                                    }
                                                    Date date2 = null;
                                                    try {
                                                        date2 = format.parse(next_created);

                                                    } catch (ParseException e) {

                                                        e.printStackTrace();
                                                    }
                                                    long difference = date2.getTime() - date1.getTime();
                                                    long days = difference / (1000 * 60 * 60 * 24);
                                                    long hours = ((difference - (1000 * 60 * 60 * 24 * days)) / (1000 * 60 * 60));
                                                    long min = (difference - (1000 * 60 * 60 * 24 * days) - (1000 * 60 * 60 * hours)) / (1000 * 60);
                                                    long sec = (difference - (1000 * 60 * 60 * 24 * days) - (1000 * 60 * 60 * hours) - (1000 * 60 * min)) / (1000);
                                                    Log.i("log_tag_inside", "Hours: " + hours + ", Mins: " + min + ",Sec: " + sec);
                                                    if (hours > 0) {
                                                        long hour_min = hours * 60;
                                                        if (min > 0) {
                                                            long total_min = (hour_min + min);
                                                            // Log.i("total_2", String.valueOf("total_min:"+total_min));
                                                            temp += (total_min);
                                                        }
                                                    } else {
                                                        long total_min = (min);
                                                        Log.i("total_outside", String.valueOf("total_min:" + total_min));
                                                        temp += (total_min);
                                                    }
                                                    //  Log.e("diff" , String.valueOf("Sec: "+min));
                                                    Log.i("data2", "Next record outside");
                                                } else if (next_status.trim().equals("outside")) {
                                                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                                    // SimpleDateFormat format = new SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
                                                    Date date1 = null;
                                                    try {
                                                        date1 = format.parse(created_at);
                                                    } catch (ParseException e) {
                                                        e.printStackTrace();
                                                    }
                                                    Date date2 = null;
                                                    try {

                                                        date2 = format.parse(next_created);

                                                    } catch (ParseException e) {

                                                        e.printStackTrace();
                                                    }
                                                    long difference = date2.getTime() - date1.getTime();
                                                    long days = difference / (1000 * 60 * 60 * 24);
                                                    long hours = ((difference - (1000 * 60 * 60 * 24 * days)) / (1000 * 60 * 60));
                                                    long min = (difference - (1000 * 60 * 60 * 24 * days) - (1000 * 60 * 60 * hours)) / (1000 * 60);
                                                    long sec = (difference - (1000 * 60 * 60 * 24 * days) - (1000 * 60 * 60 * hours) - (1000 * 60 * min)) / (1000);
                                                    Log.i("log_tag_outside", "Hours: " + hours + ", Mins: " + min + ",Sec: " + sec);
                                                    if (hours > 0) {
                                                        long hour_min = hours * 60;
                                                        if (min > 0) {
                                                            long total_min = (hour_min + min);
                                                            Log.i("total_2", String.valueOf("total_min:" + total_min));
                                                            temp -= (total_min);
                                                        }
                                                    } else {
                                                        long total_min = (min);
                                                        temp -= (total_min);

                                                        Log.i("total_inside", String.valueOf("total_min:" + total_min));
                                                    }
                                                    //  Log.e("diff" , String.valueOf("Sec: "+min));
                                                    Log.i("data3", "Next record inside");
                                                }
                                                //els
                                            }
                                        }
                                        Log.i("temp", String.valueOf(temp));
                                        long temphr = temp / 60;
                                        long tempmin = temp % 60;
                                        // Log.i("total_temp_hr", "Total Hours "+String.valueOf(temphr)+"Total temp min "+tempmin+" - Position = " + position);
                                        String selectedDateStr = DateFormat.format("EEE, MMM d, yyyy", date).toString();


                                        TextView tv = (TextView) findViewById(R.id.textview_status);
                                        tv.setText(selectedDateStr + "  (  " + String.valueOf(temphr) + " Hour " + tempmin + " Min" + ")");
                                    }


                                    //String selectedDateStr =DateFormat.format("yyyy-MM-dd HH:mm:ss",date).toString()
                                    ///   Toast.makeText(Main3Activity.this, selectedDateStr  +"  (  "+String.valueOf(temphr)+ " Hour "+tempmin+ " Min"+"  )", Toast.LENGTH_SHORT).show();
                                    // Log.i("onDateSelected", selectedDateStr +":" +String.valueOf(temphr)+"Hour"+tempmin+"Min" +" - Position = " + position);

                                    //temp = Long.parseLong(null);
                                    //temphr = Long.parseLong(null);
                                    // tempmin = Long.parseLong(null);
                                    // }

                                });

                                FloatingActionButton fab = findViewById(R.id.fab);
                                fab.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        horizontalCalendar.goToday(false);
                                    }
                                });

                            }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}