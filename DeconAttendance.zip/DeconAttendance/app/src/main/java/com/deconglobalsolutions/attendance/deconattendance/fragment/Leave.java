package com.deconglobalsolutions.attendance.deconattendance.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.deconglobalsolutions.attendance.deconattendance.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import static android.view.View.*;
import static com.deconglobalsolutions.attendance.deconattendance.app.AppConfig.URL_LOGIN;


public class Leave extends Fragment implements View.OnClickListener,AdapterView.OnItemSelectedListener {


    private EditText editTextName;
    private EditText editTextUsername;
    private EditText Description;
    private Button buttonRegister;
    private Spinner spinnerText;
    private DatePicker datePicker;
    private DatePicker datePicker1;
    ProgressDialog progressDialog;

    private static final String REGISTER_URL =  "https://deconglobalsolutions.com/attendance/cron/leave_request";

    public Leave() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View v = inflater.inflate(R.layout.fragment_leave, container, false);
        editTextUsername = (EditText) v.findViewById(R.id.sub);
        datePicker = (DatePicker) v.findViewById(R.id.dpStart);

        spinnerText = (Spinner) v.findViewById(R.id.spinner);
        Description = (EditText) v.findViewById(R.id.description);

        buttonRegister = (Button) v.findViewById(R.id.submit);

        buttonRegister.setOnClickListener(this);


        spinnerText.setOnItemSelectedListener(this);
        List<String> categories = new ArrayList<String>();
        categories.add("Medical");
        categories.add("Half Day");
        categories.add("Vacation");
        categories.add("Other");


        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinnerText.setAdapter(dataAdapter);

        return v;
    }

      @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        String item = parent.getItemAtPosition(position).toString();

        // Showing selected spinner item
       // Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();

    }

    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onClick(View v) {

        if(v == buttonRegister){
            registerUser();
        }
    }
/*
        String email = editTextName.getText().toString().trim().toLowerCase();
*/

    private void registerUser() {
        String sub = editTextUsername.getText().toString().trim().toLowerCase();
        String description = Description.getText().toString().trim().toLowerCase();
         String spinner = spinnerText.getSelectedItem().toString().trim().toLowerCase();
        String dpStart = datePicker.getYear() + "-" + datePicker.getMonth() + 1 + "-" + datePicker.getDayOfMonth();


              register(sub,spinner,dpStart,description);
    }
    private void register(final String sub, final String spinner, final String dpStart,final String description) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, REGISTER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Log.i("check:", response.toString());
                        // Log.i("Responseparse","Yes");

                            Toast.makeText(getActivity(), response, Toast.LENGTH_LONG).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<String, String>();
                map.put("sub", sub);
                map.put("spinner", spinner);
                map.put("dpstart", dpStart);
                map.put("description",description);
                return map;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(stringRequest);
    }

   /* private void register( String sub, String spinner, String dpStart) {
        String urlSuffix = "&username="+sub+"&spinner="+spinner+"&dpStart="+dpStart;
        class RegisterUser extends AsyncTask<String, Void, String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
             progressDialog = new ProgressDialog(getActivity());
             progressDialog.show();
               *//*   progressDialoge.setMessage("Getting into your information");
               *//*
            }
*//*
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(getActivity().Leave);
            }
*//*

            @Override
             protected void onPostExecute(String s) {
                super.onPostExecute(s);
                progressDialog.dismiss();
                Toast.makeText(getActivity().getApplicationContext(),s, Toast.LENGTH_LONG).show();
              }

            @Override
             protected String doInBackground(String... params) {
                String s = params[0];
                BufferedReader bufferedReader = null;
                try {
                    URL url = new URL(REGISTER_URL + s);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String result;

                    result = bufferedReader.readLine();

                    return result;
                }  catch(Exception e){
                     return null;
                }
            }
        }

        RegisterUser ru = new RegisterUser();
        ru.execute(urlSuffix);
    }*/

}


