package com.deconglobalsolutions.attendance.deconattendance.service;


import android.content.Intent;
import android.graphics.Color;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.widget.Button;
import android.widget.Toast;


import com.deconglobalsolutions.attendance.deconattendance.Main3Activity;
import com.deconglobalsolutions.attendance.deconattendance.R;

import com.example.horizontalcalendar.HorizontalCalendar;
import com.example.horizontalcalendar.module.CalendarEvent;
import com.example.horizontalcalendar.utils.CalendarEventsPredicate;
import com.example.horizontalcalendar.utils.HorizontalCalendarListener;


import java.util.ArrayList;
import java.util.Calendar;

import java.util.List;

import java.util.Random;

import static android.view.View.*;

public class StatusActivity extends AppCompatActivity {


    private HorizontalCalendar horizontalCalendar;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);
        btn =(Button) findViewById(R.id.status);
        btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),Main3Activity.class);
                startActivity(i);
            }
        });

    }
}
       /* Toolbar toolbar = findViewById(R.id.toolbar);
       setSupportActionBar(toolbar);

        *//* start 2 months ago from now *//*
        Calendar startDate = Calendar.getInstance();
        startDate.add(Calendar.MONTH, -2);

        *//* end after 2 months from now *//*
        Calendar endDate = Calendar.getInstance();
        endDate.add(Calendar.MONTH, 2);

        // Default Date set to Today.
        final Calendar defaultSelectedDate = Calendar.getInstance();


        horizontalCalendar = new HorizontalCalendar.Builder(this, R.id.calendarView)
                .range(startDate, endDate)
                .datesNumberOnScreen(5)
                .configure()
                .formatTopText("MMM")
                .formatMiddleText("dd")
                .formatBottomText("EEE")
                .showTopText(true)
                .showBottomText(true)
                .textColor(Color.LTGRAY, Color.WHITE)
                .colorTextMiddle(Color.LTGRAY, Color.parseColor("#ffd54f"))
                .end()
                .defaultSelectedDate(defaultSelectedDate)
                .addEvents(new CalendarEventsPredicate() {

                    Random rnd = new Random();
                    @Override
                    public List<CalendarEvent> events(Calendar date) {
                        List<CalendarEvent> events = new ArrayList<>();

                        //events.add(defaultSelectedDate,DrawableUtils.canSafelyMutateDrawable(this,"M"));
//            Calendar calendar = Calendar.getInstance();
//            events.add(new CalendarEvent(calendar, devs.mulham.raee.sample.DrawableUtils.getCircleDrawableWithText(Context context, "M")));
                        int count = rnd.nextInt(6);

                        for (int i = 0; i <= count; i++){
                            events.add(new CalendarEvent(Color.rgb(rnd.nextInt(120), rnd.nextInt(1), rnd.nextInt(11)), "event"));
                        }

                        return events;
                    }
                })
                .build();

        Log.i("Default Date", DateFormat.format("EEE, MMM d, yyyy", defaultSelectedDate).toString());

        horizontalCalendar.setCalendarListener(new HorizontalCalendarListener() {
            @Override
            public void onDateSelected(Calendar date, int position) {
                String selectedDateStr = DateFormat.format("EEE, MMM d, yyyy", date).toString();
                Toast.makeText(StatusActivity.this, selectedDateStr + " selected!", Toast.LENGTH_SHORT).show();
                Log.i("onDateSelected", selectedDateStr + " - Position = " + position);
            }

        });

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                horizontalCalendar.goToday(false);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}*/


    /*CompactCalendarView compactCalendar;
    private SimpleDateFormat dateFormatMonth = new SimpleDateFormat("MMMM-yyyy", Locale.getDefault());




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);
        setTitle("status");




        final android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(false);
        actionBar.setTitle(null);
        compactCalendar = (CompactCalendarView) findViewById(R.id.compactcalendar_view);
        compactCalendar.setUseThreeLetterAbbreviation(true);
        Event ev1 = new Event(Color.GREEN, 147705480000L, "Teacer ' Professional Day");
        compactCalendar.addEvent(ev1);

        compactCalendar.setListener(new CompactCalendarView.CompactCalendarViewListener() {
             @Override
             public void onDayClick(Date dateClicked) {
                Context context = getApplicationContext();
                if (dateClicked.toString().compareTo("Fri  09:00:00 Ast 2018") == 0 ) {
                    Toast.makeText(context, "Teacher ' Professional day", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(context,"No event planned for that day", Toast.LENGTH_SHORT).show();
                }
                }

            @Override
            public void onMonthScroll(Date firstDayOfNewMonth) {
             actionBar.setTitle(dateFormatMonth.format(firstDayOfNewMonth));
            }
        });



    }
}*/
