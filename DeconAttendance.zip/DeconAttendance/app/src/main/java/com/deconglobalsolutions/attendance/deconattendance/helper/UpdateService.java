package com.deconglobalsolutions.attendance.deconattendance.helper;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.IBinder;
import android.provider.CallLog;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ListAdapter;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;

import static com.deconglobalsolutions.attendance.deconattendance.app.AppConfig.URL_CALL;
import static com.deconglobalsolutions.attendance.deconattendance.app.AppConfig.URL_LOCATION;
import static com.deconglobalsolutions.attendance.deconattendance.app.AppConfig.URL_LOGIN;


public class UpdateService extends Service {
    public static final long NOTIFY_INTERVAL    =    60 * 1000;//20 * 60 * 1000; // 10 seconds
    private Handler mHandler                    =   new Handler();
    private Timer mTimer                        =   null;
    public static String URI = "http://203.122.21.147/mac.php";
    protected static final String TAG = "LocationUpdateService";
    public static final long UPDATE_INTERVAL_IN_MILLISECONDS =  10 * 1000;
    public static final long FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = UPDATE_INTERVAL_IN_MILLISECONDS ;
    protected final static String REQUESTING_LOCATION_UPDATES_KEY = "requesting-location-updates-key";
    protected final static String LOCATION_KEY = "location-key";
    protected final static String LAST_UPDATED_TIME_STRING_KEY = "last-updated-time-string-key";
    public static Boolean mRequestingLocationUpdates;
    protected String mLastUpdateTime;
    protected GoogleApiClient mGoogleApiClient;
    protected LocationRequest mLocationRequest;
    protected Location mCurrentLocation;
    public static boolean isEnded = false;
    private Button btnInsert, btnUpdate, btnSelect, btnDelete;
    private SQLiteHandler sqLiteHandler1;
    private Cursor cursor,cursor3,cursor4;
    private String unique_id,celllocation,simoperator,simserial,linenumber,status_start,dated_start,status_end,dated_end;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
  /*      if (mTimer != null) {mTimer.cancel();}
        else {mTimer = new Timer();}
        mTimer.scheduleAtFixedRate(new TimeDisplayTimerTask(), 0, NOTIFY_INTERVAL);
        sqLiteHandler1 = new SQLiteHandler(getApplicationContext());
  */  }

  /*  public class TimeDisplayTimerTask extends TimerTask {
*//*
        @Override
        public void run() {
            boolean post = mHandler.post(new Runnable() {
                @Override
                public void run() {
                    cursor = sqLiteHandler1.selectRecords_setting();
                    cursor.moveToFirst();
                    String call = cursor.getString(cursor.getColumnIndex(SQLiteHandler.KEY_CALL_LOG));
                    String sms = cursor.getString(cursor.getColumnIndex(SQLiteHandler.KEY_SMS_LOG));
                    if (Integer.parseInt(call) == 1) {
                        Log.i("test", "STop service call log");
                        String t = getCallDetails();
                        //Log.i("newtestcall",t);
                        */
/*sendcalldetails("yogi@gmail.com","8008888","incoming","467");*//*

                    }
                    if (Integer.parseInt(sms) == 1) {
                        Log.i("test1", "STop service sms log");


                        ContentResolver contentResolver = getApplicationContext().getContentResolver();
*/

                    }

                        /*
                        Cursor smsInboxCursor = contentResolver.query(Uri.parse("content://sms/inbox"),null,null,null,null);

                        int indexAddress = smsInboxCursor.getColumnIndex("address");
                        int indexBody= smsInboxCursor.getColumnIndex("body");
                        if(indexBody < 0 || !smsInboxCursor.moveToFirst())return;

                        do {
                            String str = "SMS Form:" + smsInboxCursor.getString(indexAddress) + "\n" + smsInboxCursor.getString(indexBody) + "\n";

                            Log.i("newtestsms",str);



                        }while (smsInboxCursor.moveToNext());

                    }
                    cursor.close();


                }
            });
        }
    }


*/



/*
    private String getCallDetails() {
        StringBuffer sb = new StringBuffer();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            return "";
        }
        Cursor managedCursor = this.getContentResolver().query(CallLog.Calls.CONTENT_URI, null, null, null, null);
        int number = managedCursor.getColumnIndex(CallLog.Calls.NUMBER);
        int type = managedCursor.getColumnIndex(CallLog.Calls.TYPE);
        int date = managedCursor.getColumnIndex(CallLog.Calls.DATE);
        int duration = managedCursor.getColumnIndex(CallLog.Calls.DURATION);
        sb.append("Call Details\n\n :");

        while (managedCursor.moveToNext()) {
            String phNumber = managedCursor.getString(number);
            String callType = managedCursor.getString(type);
            String callDate = managedCursor.getString(date);
            Date callDayTime = new Date(Long.valueOf(callDate));
            String callDuration = managedCursor.getString(duration);

            String dir = null;
            int dircode = Integer.parseInt(callType);
            switch (dircode) {
                case CallLog.Calls.OUTGOING_TYPE:
                    dir = "OUTGOING";
              */
/*      sendcalldetails("yogi@gmail.com",phNumber,dir,String.valueOf(callDayTime));
                *//*
    break;

                case CallLog.Calls.INCOMING_TYPE:
                    dir = "INCOMING";
                  */
/*  sendcalldetails("yogi@gmail.com",phNumber,dir,String.valueOf(callDayTime));
                  *//*
  break;

                case CallLog.Calls.MISSED_TYPE:
                    dir = "MISSED";
                    */
/*sendcalldetails("yogi@gmail.com",phNumber,dir,String.valueOf(callDayTime));
                    *//*
break;
            }
            sb.append("\nPhone Number:" + phNumber + "\nCall Type:" + dir + "\nCall Date" + callDayTime */
/*+ "\nCall duration" +
                    callDuration*//*
);
           */
/* sendcalldetails("yogi@gmail.com",phNumber,dir,String.valueOf(callDayTime));
           *//*
sb.append("\n----------------------------------");
            sb.append(System.getProperty("line.Separator"));

        }

        Cursor cursor1 = sqLiteHandler1.getListContents();
        cursor1.moveToFirst();

        String call = cursor.getString(cursor.getColumnIndex(SQLiteHandler.KEY_CALL_LOG));
        String sms = cursor.getString(cursor.getColumnIndex(SQLiteHandler.KEY_SMS_LOG));

        Cursor data = sqLiteHandler1.getListContents();
        data.moveToFirst();
        sendcalldetails("yogi@gmail.com","801010101","incoming","4:40pm");

        managedCursor.close();
        return sb.toString();

    }


    private void sendcalldetails(final String email,final String phone_number, final String call_type,final String call_date) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_CALL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<String, String>();
                map.put("email", email);
                map.put("phone_number",phone_number);
                map.put("call_type", call_type);
                map.put("call_date",call_date);
                return map;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext().getApplicationContext());
        requestQueue.add(stringRequest);
    }




    public static boolean isInternetWorking() {
        boolean success = false;
        try {
            URL url = new URL("https://google.com");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(10000);
            connection.connect();
            success = connection.getResponseCode() == 200;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return success;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mTimer = new Timer();
        mTimer.scheduleAtFixedRate(new TimeDisplayTimerTask(), 0, NOTIFY_INTERVAL);
    }
}
*/
