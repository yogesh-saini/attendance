package com.deconglobalsolutions.attendance.deconattendance;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import com.deconglobalsolutions.attendance.deconattendance.helper.SQLiteHandler;
import com.deconglobalsolutions.attendance.deconattendance.helper.SessionManager;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofenceStatusCodes;
import com.google.android.gms.location.GeofencingEvent;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.model.LatLng;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

//import static com.deconglobalsolutions.attendance.deconattendance.Main2Activity.REQUEST_LOCATION;
import static com.google.android.gms.common.GooglePlayServicesUtil.getErrorString;

/**
 * Created by decon-pc on 4/28/2018.
 */

public class GeofenceTrasitionService extends IntentService implements
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        com.google.android.gms.location.LocationListener {

    static final int REQUEST_LOCATION = 1;
    LocationManager locationManager;
    List<String> listLocation = null;

    private static final String TAG = GeofenceTrasitionService.class.getSimpleName();

    public static final int GEOFENCE_NOTIFICATION_ID = 0;
    private SQLiteHandler db;
    protected final static String REQUESTING_LOCATION_UPDATES_KEY = "requesting-location-updates-key";
    protected final static String LOCATION_KEY = "location-key";
    protected final static String LAST_UPDATED_TIME_STRING_KEY = "last-updated-time-string-key";
    public static Boolean mRequestingLocationUpdates;
    protected LocationRequest mLocationRequest;
    protected Location mCurrentLocation;
    private Cursor cursor, cursor2, cursor3, cursor4;
    private SessionManager session;
    private GeofencingEvent geofencingEvent;

    protected String mLastUpdateTime;

    public GeofenceTrasitionService() {
        super(TAG);
    }

    @TargetApi(Build.VERSION_CODES.M)
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onHandleIntent(@Nullable Intent intent) {

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        db = new SQLiteHandler(getApplicationContext());
        session = new SessionManager(getApplicationContext());
        geofencingEvent = GeofencingEvent.fromIntent(intent);
        // Handling errors
        if (geofencingEvent.hasError()) {

            String errorMsg = getErrorString(geofencingEvent.getErrorCode());
            Log.e(TAG, errorMsg);

            return;
        }


        int geoFenceTransition = geofencingEvent.getGeofenceTransition();

        if (geoFenceTransition == Geofence.GEOFENCE_TRANSITION_ENTER ||
                geoFenceTransition == Geofence.GEOFENCE_TRANSITION_EXIT) {
            // Get the geofence that were triggered
            List<Geofence> triggeringGeofences = geofencingEvent.getTriggeringGeofences();

            String geofenceTransitionDetails = getGeofenceTrasitionDetails(geoFenceTransition, triggeringGeofences);

            // Send notification details as a String
            sendNotification(geofenceTransitionDetails);
        }


    }

//        Location current_location = geofencingEvent.getTriggeringLocation();
//        double c_lattitude =current_location.getLatitude();
//        double c_longitude =current_location.getLongitude();








/*
        if (map != null) {
*/
    // Remove last geoFenceMarker
           /* if (geoFenceMarker != null)
                geoFenceMarker.remove();

            geoFenceMarker = map.addMarker(markerOptions);
            Log.e("MAIN ACTIVITY ", "GEOFENCE :" + geoFenceMarker);*/



    @TargetApi(Build.VERSION_CODES.N)
    @RequiresApi(api = Build.VERSION_CODES.M)
    private String getGeofenceTrasitionDetails(int geoFenceTransition, List<Geofence> triggeringGeofences) {

        if (session.isLoggedIn()) {


            ArrayList<String> triggeringGeofencesList = new ArrayList<>();
            for (Geofence geofence : triggeringGeofences) {
                triggeringGeofencesList.add(geofence.getRequestId());
            }


            Calendar cal = Calendar.getInstance();
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            df.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
            String created_at = df.format(cal.getTime());


            String status = null;
            if (geoFenceTransition == Geofence.GEOFENCE_TRANSITION_ENTER) {
                status = "inside";


                TelephonyManager telephonyManager = (TelephonyManager) getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    return "";
                }

                Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

                String latti = String.valueOf(location.getLatitude());
                String longi = String.valueOf(location.getLongitude());


                String deviceId1 = telephonyManager.getDeviceId(1).trim();
                String deviceId2 = telephonyManager.getDeviceId(2).trim();

                Calendar calendar = Calendar.getInstance();
                SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                df2.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
                String timenow = df2.format(calendar.getTime());

                Cursor c1 = db.selectCount(timenow);

                c1.moveToFirst();
                int c = c1.getInt(c1.getColumnIndex("total"));
                int c_min_diff = c1.getInt(c1.getColumnIndex("min_diff"));
                Log.i("time_test", c + " " + c_min_diff);
                Cursor d2 = db.selectCount1(timenow);
                d2.moveToFirst();
                int er = d2.getInt(d2.getColumnIndex("total"));
                int df_min_diff = d2.getInt(d2.getColumnIndex("min_diff"));

                Log.i("time_test1", er + " " + df_min_diff);

                Cursor cur3 = db.counttable_office();
                //int[] arr = new int[cur3.getCount()+1000];
                //int j =0;
                Map<Integer, Integer> map = new HashMap<>();
                cur3.moveToFirst();
                do {
                    listLocation = new ArrayList<>();
                    String office_lat = cur3.getString(cur3.getColumnIndex("office_lat"));
                    String office_lng = cur3.getString(cur3.getColumnIndex("office_lng"));
                    final int office_name = cur3.getInt(cur3.getColumnIndex("office_id"));
                    double of_lattitude = Double.parseDouble(office_lat);
                    double of_longitude = Double.parseDouble(office_lng);
                    final  LatLng office_e = new LatLng(of_lattitude, of_longitude);

                    Location current_location = geofencingEvent.getTriggeringLocation();
                    double c_lattitude =current_location.getLatitude();
                    double c_longitude =current_location.getLongitude();
                    final  LatLng office_c = new LatLng(c_lattitude, c_longitude);
                    final double distance_count= CalculationByDistance(office_c,office_e);
                    Log.i("Distance_cont",String.valueOf(distance_count));
                    /// listLocation.add(String.valueOf(distance_count));
                    Integer  int_office_dist = ( (Double) Math.ceil( distance_count ) ).intValue();
                    Log.i("Distance_cont2",String.valueOf(int_office_dist));
                    map.put(office_name,int_office_dist);

                } while (cur3.moveToNext());

                Cursor cur = db.group_in_out();
                if (cur.moveToFirst()) {
                    do {
                        String boundary_st = cur.getString(0);
                        String boundary_time = cur.getString(1);
                        Log.i("testing", boundary_st + " " + boundary_time);
                        //Toast.makeText(getApplicationContext(),boundary_st+" "+boundary_time,Toast.LENGTH_LONG).show();
                    } while (cur.moveToNext());
                }
                Map<Integer, Integer> sorted = sortByValues(map);
                Map.Entry<Integer,Integer> entry = sorted.entrySet().iterator().next();
                //String key = entry.getKey();
                //String value = entry.getValue();
                Log.i("check_tm",String.valueOf(entry.getValue()));
                final String office_id =String.valueOf(entry.getKey());


                // if(cur)
                // Toast.makeText(getApplicationContext(),c+" Inside",Toast.LENGTH_LONG).show();
                //Log.i("chekin",c+ " In");
                if (c == 0) {
                    db.addLocData("", latti, longi, status, "1234", "410", deviceId1, deviceId2, created_at,office_id);
                    Log.i("data_re" ,""+ latti+ longi+ status+ "1234"+ "410"+ deviceId1+ deviceId2+ created_at +"\n");
                } else if (er >= 1) {
                    db.addLocData("", latti, longi, status, "1234", "410", deviceId1, deviceId2, created_at,office_id);

                } else {
                    if ((c >= 0) && (c_min_diff >= 840)) {
                        db.addLocData("", latti, longi, status, "1234", "410", deviceId1, deviceId2, created_at,office_id);

                    }
                }

            } else if (geoFenceTransition == Geofence.GEOFENCE_TRANSITION_EXIT) {
                status = "outside";


                TelephonyManager telephonyManager = (TelephonyManager) getApplicationContext().getSystemService(Context.TELEPHONY_SERVICE);
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    return "";

                }
                Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

                String latti = String.valueOf(location.getLatitude());
                String longi = String.valueOf(location.getLongitude());

                String deviceId1 = telephonyManager.getDeviceId(1).trim();
                String deviceId2 = telephonyManager.getDeviceId(2).trim();
                //int d = db.selectCount("outside");
                // if (d == 0) {

                Calendar calendar = Calendar.getInstance();
                SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                df2.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
                String timenow = df2.format(calendar.getTime());
                Cursor cur3 = db.counttable_office();
                //int[] arr = new int[cur3.getCount()+1000];
                //int j =0;
                Map<Integer, Integer> map = new HashMap<>();
                cur3.moveToFirst();
                do {
                    listLocation = new ArrayList<>();
                    String office_lat = cur3.getString(cur3.getColumnIndex("office_lat"));
                    String office_lng = cur3.getString(cur3.getColumnIndex("office_lng"));
                    final int office_name = cur3.getInt(cur3.getColumnIndex("office_id"));
                    double of_lattitude = Double.parseDouble(office_lat);
                    double of_longitude = Double.parseDouble(office_lng);
                    final  LatLng office_e = new LatLng(of_lattitude, of_longitude);

                    Location current_location = geofencingEvent.getTriggeringLocation();
                    double c_lattitude =current_location.getLatitude();
                    double c_longitude =current_location.getLongitude();
                    final  LatLng office_c = new LatLng(c_lattitude, c_longitude);
                    final double distance_count= CalculationByDistance(office_c,office_e);
                    Log.i("Distance_cont",String.valueOf(distance_count));
                    /// listLocation.add(String.valueOf(distance_count));
                    Integer  int_office_dist = ( (Double) Math.ceil( distance_count ) ).intValue();
                    Log.i("Distance_cont2",String.valueOf(int_office_dist));
                    map.put(office_name,int_office_dist);
                    // arr[office_name] =int_office_dist;
                    //                Log.i("off_lat", String.valueOf(listLocation));
                    //                Cursor cur1 = db.select_office_id(String.valueOf(c_lattitude), String.valueOf(c_longitude));
                    //                cur1.moveToFirst();
                    //                String office_id = cur1.getString(cur1.getColumnIndex(SQLiteHandler.KEY_OFFICE_ID));
                    //String office_id = cur1.getString(get);
                    //Log.i("off", office_id);
                    // LatLng ggn2 = new LatLng(off_lat, off_lng);
                    // listLocation.add(new LatLng(off_lat, off_lng));
                } while (cur3.moveToNext());
                Map<Integer, Integer> sorted = sortByValues(map);
                Map.Entry<Integer,Integer> entry = sorted.entrySet().iterator().next();
                //String key = entry.getKey();
                //String value = entry.getValue();
                final String office_id =String.valueOf(entry.getKey());

                db.addLocData("2", latti, longi, status, "5678", "32", deviceId1, deviceId2, created_at,office_id);
                // Toast.makeText(getApplication(),"test" +c+":"+ "time" +c_min_diff,Toast.LENGTH_LONG).show();

            }

            return status + TextUtils.join(", ", triggeringGeofencesList);

        }
        return null;
    }
    public static <K extends Comparable,V extends Comparable> Map<K,V> sortByValues(Map<K,V> map){
        List<Map.Entry<K,V>> entries = new LinkedList<Map.Entry<K,V>>(map.entrySet());

        Collections.sort(entries, new Comparator<Map.Entry<K,V>>() {

            @Override
            public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2) {
                return o1.getValue().compareTo(o2.getValue());
            }
        });

        //LinkedHashMap will keep the keys in the order they are inserted
        //which is currently sorted on natural ordering
        Map<K,V> sortedMap = new LinkedHashMap<K,V>();

        for(Map.Entry<K,V> entry: entries){
            sortedMap.put(entry.getKey(), entry.getValue());
        }

        return sortedMap;
    }

    private String getMinKey(Map<Integer, Integer> map, String... keys) {
        String minKey = null;
        int minValue = Integer.MAX_VALUE;
        for(String key : keys) {
            int value = map.get(key);
            if(value < minValue) {
                minValue = value;
                minKey = key;
            }
        }
        return String.valueOf(minValue);
    }

    public static int getMin(int[] inputArray){

        int minValue = inputArray[0];
        int minkey;
        for(int i=1;i<inputArray.length;i++){
            if(inputArray[i] < minValue){
                minValue = inputArray[i];

            }
        }
        return minValue;
    }
    public double CalculationByDistance(LatLng StartP, LatLng EndP) {
        int Radius = 6371;// radius of earth in Km
        double lat1 = StartP.latitude;
        double lat2 = EndP.latitude;
        double lon1 = StartP.longitude;
        double lon2 = EndP.longitude;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2)
                * Math.sin(dLon / 2);
        double c = 2 * Math.asin(Math.sqrt(a));
        double valueResult = Radius * c;
        double km = valueResult / 1;
        DecimalFormat newFormat = new DecimalFormat("####");
        int kmInDec = Integer.valueOf(newFormat.format(km));
        double meter = valueResult % 1000;
        int meterInDec = Integer.valueOf(newFormat.format(meter));
        Log.i("Radius Value", "" + valueResult + "   KM  " + kmInDec
                + " Meter   " + meterInDec);

        return Radius * c;
    }
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void sendNotification(String msg) {
        Log.i(TAG, "sendNotification: " + msg);

        // Intent to start the main Activity
        Intent notificationIntent = Main2Activity.makeNotificationIntent(
                getApplicationContext(), msg
        );

        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
        stackBuilder.addParentStack(Main2Activity.class);
        stackBuilder.addNextIntent(notificationIntent);
        PendingIntent notificationPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);


        NotificationManager notificatioMng =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificatioMng.notify(
                GEOFENCE_NOTIFICATION_ID,
                createNotification(msg, notificationPendingIntent));

    }

    private Notification createNotification(String msg, PendingIntent notificationPendingIntent) {
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this);
        notificationBuilder
                .setSmallIcon(R.drawable.icon_person2)
                /* .setColor(Color.RED)*/
                .setContentTitle(msg)
                .setContentText("Notification!")
                .setContentIntent(notificationPendingIntent)
                .setDefaults(Notification.DEFAULT_LIGHTS | Notification.DEFAULT_VIBRATE | Notification.DEFAULT_SOUND)
                .setAutoCancel(true);
        return notificationBuilder.build();
    }


    public static String getErrorString(int errorCode) {
        switch (errorCode) {
            case GeofenceStatusCodes.GEOFENCE_NOT_AVAILABLE:
                return "GeoFence not available";
            case GeofenceStatusCodes.GEOFENCE_TOO_MANY_GEOFENCES:
                return "Too many GeoFences";
            case GeofenceStatusCodes.GEOFENCE_TOO_MANY_PENDING_INTENTS:
                return "Too many pending intents";
            default:
                return "Unknown error.";
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {

    }

}







/*
private class AsyncSender extends AsyncTask<String, Void, Void> {

    private String Content;
    private String Error = null;
    private final String TAG = null;
    private ProgressDialog Dialog = new ProgressDialog(GeofenceTrasitionService.this);

    protected Void doInBackground(String... urls) {
        if ((ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) && (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return TODO;
        }
        Location mLastLocation = LocationServices.FusedLocationApi.getLastLocation(GoogleApiClient);
        if (mLastLocation != null) {
            String lat                      =   Double.toString(mLastLocation.getLatitude());
            String lng                      =   Double.toString(mLastLocation.getLongitude());
            Calendar c                      =   Calendar.getInstance();
            SimpleDateFormat df             =   new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            df.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
            String formattedDate            =   df.format(c.getTime());

            TelephonyManager tManager       =    (TelephonyManager) getBaseContext().getSystemService(Context.TELEPHONY_SERVICE);
            */
/*tManager.getDeviceId();*//*

            String imei                     =   tManager.getDeviceId().toString();

            int state = tManager.getSimState();

            if(state == TelephonyManager.SIM_STATE_ABSENT){
                unique_id                =   "";
                celllocation             =   "";
                simoperator              =   "";
                simserial                =   "";
                linenumber               =   "";
            }
            else if(state ==  TelephonyManager.SIM_STATE_READY){
                unique_id                =   Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
                celllocation             =   tManager.getCellLocation().toString();
                simoperator              =   tManager.getSimOperatorName().toString();
                simserial                =   tManager.getSimSerialNumber().toString();
                linenumber               =   tManager.getLine1Number().toString();
            }

            dbHelper.inserRecord(lat, lng,formattedDate);
            cursor = dbHelper.selectRecords_sendsms();
            int count = cursor.getCount();
            if(count>0) {
                if (cursor.moveToFirst()) {
                    String dated        = cursor.getString(cursor.getColumnIndex(DbHelper.DATED));
                    String datePast     = dated;
                    String dateToday    = formattedDate;

                    long diff_found     = diff_time(datePast,dateToday);
                    if(diff_found >=1){
                        String mess     =  ""+lat + "," + lng +"\n"+imei+"\n"+simserial+","+simoperator+"\n"+celllocation+"\n"+linenumber;
                        //Toast.makeText(getBaseContext(), mess, Toast.LENGTH_SHORT).show();
                        sendSMS("9560498178", mess);
                        dbHelper.updateRecord_sendsms(formattedDate);
                    }
                }
            }
            else {
                //String mess     =   "Lat =: "+lat + "\n Lng =: " + lng +"\n Imei =: "+imei+"\n Deviceid =: "+unique_id +"\n Cell Location =: "+celllocation+ "\n Sim Operator =: "+simoperator+"\n Sim serial =: "+simserial+"\n Date =: "+formattedDate+"\n Phone =: "+linenumber+"";
                String mess     =  ""+lat + "," + lng +"\n"+imei+"\n"+simserial+","+simoperator+"\n"+celllocation+"\n"+linenumber;
                sendSMS("9560498178", mess);
                dbHelper.inserRecord_sendsms(formattedDate);
            }
        }
        return null;
    }


    private void sendSMS(String s, String mess) {
    }


    private long diff_time(String datePast,String dateToday){
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date d1 = null;
        Date d2 = null;
        try {
            d1 = format.parse(datePast);
            d2 = format.parse(dateToday);
            diff           = d2.getTime() - d1.getTime();
            diffSeconds    = diff / 1000 % 60;
            diffMinutes    = diff / (60 * 1000) % 60;
            diffHours      = diff / (60 * 60 * 1000) % 24;
            diffDays       = diff / (24 * 60 * 60 * 1000);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return diffDays;
    }
private class OneTimeSender extends AsyncTask<String, Void, Void> {

    private final HttpClient Client = new DefaultHttpClient();
    private String Content;
    private String Error = null;
    private final String TAG = null;
    private ProgressDialog Dialog = new ProgressDialog(TimeService.this);
    protected Void doInBackground(String... urls) {

        try {
            Location  mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
            if (mLastLocation != null) {
                TelephonyManager tManager       =   (TelephonyManager) getBaseContext().getSystemService(Context.TELEPHONY_SERVICE);
                String lat                      =   Double.toString(mLastLocation.getLatitude());
                String lng                      =   Double.toString(mLastLocation.getLongitude());
                String unique_id                =   Settings.Secure.getString(getApplicationContext().getContentResolver(), Settings.Secure.ANDROID_ID);
                String imei                     =   tManager.getDeviceId().toString();
                String celllocation             =   tManager.getCellLocation().toString();
                String simoperator              =   tManager.getSimOperatorName().toString();
                String simserial                =   tManager.getSimSerialNumber().toString();
                String linenumber               =   tManager.getLine1Number().toString();
                Calendar c                      =   Calendar.getInstance();
                SimpleDateFormat df             =   new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                df.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
                String formattedDate            =   df.format(c.getTime());

                String dated_start              =   send_start();
                String dated_end                =   send_end();


                HttpPost httppost = new HttpPost(URL);
                String nm   =   lat + "=>" + lng +"=>"+unique_id+"=>"+imei +"=>"+celllocation+ "=>"
                        +simoperator+"=>"+simserial+"=>"+formattedDate+"=>"+linenumber + "=>"+dated_start+"=>"+dated_end;
                JSONObject jObject = new JSONObject();
                jObject.put("name", nm);
                MultipartEntity se = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
                se.addPart("request", new StringBody(jObject.toString()));
                httppost.setEntity(se);
                HttpResponse resp = Client.execute(httppost);
                Content = EntityUtils.toString(resp.getEntity());
                //Log.e("Response", "--------------------------------" + Content);
                // Log.i("Response1", "--------------------------------" + nm);
                //Toast.makeText(getApplicationContext(),nm,Toast.LENGTH_LONG).show();
                dbHelper.inserRecord(lat, lng,formattedDate);
            }
        }
        catch (JSONException e)                 {e.printStackTrace();}
        catch (UnsupportedEncodingException e)  {e.printStackTrace();}
        catch (ClientProtocolException e)       {e.printStackTrace();}
        catch (IOException e)                   {e.printStackTrace();}
        return null;
    }

}

    public String send_start(){
        cursor3                 =   dbHelper.selectRecords_startstatus();
        cursor3.moveToFirst();
        if(cursor3.getCount()>0) {
            String status_start = cursor3.getString(cursor3.getColumnIndex(DbHelper.STATUS));
            String dated_start = cursor3.getString(cursor3.getColumnIndex(DbHelper.DATED));
            Log.i("start", status_start + dated_start);
            return dated_start;
        }
        else {
            return null;
        }
    }
    public String send_end(){
        cursor4                 =   dbHelper.selectRecords_endstatus();
        cursor4.moveToFirst();
        if(cursor4.getCount()>0) {
            String status_end = cursor4.getString(cursor4.getColumnIndex(DbHelper.STATUS));
            String dated_end = cursor4.getString(cursor4.getColumnIndex(DbHelper.DATED));
            Log.i("end", dated_end + status_end);
            return dated_end;
        }
        else {
            return null;
        }
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("LOC", "Service init...");
        isEnded = false;
        mRequestingLocationUpdates = false;
        mLastUpdateTime = "";
        buildGoogleApiClient();
        if (mGoogleApiClient.isConnected() && mRequestingLocationUpdates) {
            startLocationUpdates();
            mTimer = new Timer();
            mTimer.scheduleAtFixedRate(new TimeDisplayTimerTask(), 0, NOTIFY_INTERVAL);
        }
        return Service.START_REDELIVER_INTENT;
    }
}*/
