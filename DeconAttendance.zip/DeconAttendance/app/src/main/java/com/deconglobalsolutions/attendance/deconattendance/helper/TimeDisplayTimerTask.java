package com.deconglobalsolutions.attendance.deconattendance.helper;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;

import com.google.android.gms.common.ConnectionResult;

/**
 * Created by decon-pc on 5/3/2018.
 */

interface TimeDisplayTimerTask {
    int onStartCommand(Intent intent, int flags, int startId);

    void onConnected(Bundle bundle);

    void onConnectionSuspended(int i);

    void onLocationChanged(Location location);

    void onConnectionFailed(ConnectionResult connectionResult);
}
