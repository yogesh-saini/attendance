package com.deconglobalsolutions.attendance.deconattendance.fragment;


import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;


import com.deconglobalsolutions.attendance.deconattendance.Camera;
import com.deconglobalsolutions.attendance.deconattendance.Main2Activity;
import com.deconglobalsolutions.attendance.deconattendance.R;
import com.deconglobalsolutions.attendance.deconattendance.helper.SQLiteHandler;
import com.deconglobalsolutions.attendance.deconattendance.helper.SessionManager;
import com.deconglobalsolutions.attendance.deconattendance.service.StatusActivity;

import java.util.ArrayList;

import de.codecrafters.tableview.TableView;
import de.codecrafters.tableview.listeners.TableDataClickListener;
import de.codecrafters.tableview.toolkit.SimpleTableDataAdapter;
import de.codecrafters.tableview.toolkit.SimpleTableHeaderAdapter;

//import com.deconindia.d10auth.helper.SQLiteHandler;
//import com.deconindia.d10auth.helper.SessionManager;

/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragment extends Fragment implements View.OnClickListener {
    Button button, mButton, Button1, Button2, Button3, Button4, Button5 ;
    private SessionManager session;
    private SQLiteHandler db;
    SQLiteHandler myDB;

    public ProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Profile");
        db = new SQLiteHandler(getActivity().getApplicationContext());
        myDB = new SQLiteHandler(getActivity().getApplicationContext());
        session = new SessionManager(getActivity().getApplicationContext());
        if (!session.isLoggedIn()) {
            logoutUser();
        }

        View v = inflater.inflate(R.layout.fragment_profile, container, false);
        button = (Button) v.findViewById(R.id.button);
     //   photo = (Button) v.findViewById(R.id.camera);
       // photo.setOnClickListener(this);

        button.setOnClickListener(this);
        Cursor data = myDB.getListContents();
        if (data.getCount() == 0) {
            Toast.makeText(getActivity(), "There are no contents in this list!", Toast.LENGTH_LONG).show();
        } else {
            data.moveToFirst();

            mButton = (Button) v.findViewById(R.id.contact);
            Button1 = (Button) v.findViewById(R.id.button1);
            Button2 = (Button) v.findViewById(R.id.button2);
            Button3 = (Button) v.findViewById(R.id.button3);
            Button4 = (Button) v.findViewById(R.id.button4);
            Button5 = (Button) v.findViewById(R.id.button5);

            /*LinearLayout.LayoutParams Params1 = new LinearLayout.LayoutParams(,50);
            tv.setLayoutParams(Params1);*/
            mButton.setText("NAME" + "  \t\t\t\t\t : \t\t\t " + data.getString(1));
            Button1.setText("EMAIL" + " \t\t\t\t\t\t : \t\t\t " + data.getString(2));
            Button2.setText("EMP_ID" + "\t\t\t\t\t : \t\t\t " + data.getString(4));
            Button3.setText("OFFICE" + "\t\t\t\t\t : \t\t\t " + data.getString(5));
            Button4.setText("OFFICE_LAT" + "\t\t   : \t\t\t " + data.getString(7));
            Button5.setText("OFFICE_LNG" + "\t\t   : \t\t\t " + data.getString(8));


        /*Button btn1=(Button)v.findViewById(R.id.btn1);
        Button btn2=(Button)v.findViewById(R.id.btn2);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);*/


            //////////

  /*      final TableView<String[]> tb = (TableView<String[]>) v.findViewById(R.id.tableView);
        tb.setColumnCount(4);
        tb.setHeaderBackgroundColor(Color.parseColor("#2ecc71"));

        tb.setHeaderAdapter(new SimpleTableHeaderAdapter(getActivity(),table));
        tb.setDataAdapter(new SimpleTableDataAdapter(getActivity(),tableview));

        populateData();

        tb.addDataClickListener(new TableDataClickListener() {
                                    @Override
                                    public void onDataClicked(int rowIndex, Object clickedData) {
                                        Toast.makeText(getActivity(), ((String[])clickedData)[1], Toast.LENGTH_SHORT).show();
                                    }
        });

*/


   /*     ListView listView = (ListView) v.findViewById(R.id.listView);
        ArrayList<String> theList = new ArrayList<>();
        Cursor data = myDB.getListContents();
        if (data.getCount() == 0) {
            Toast.makeText(getActivity(), "There are no contents in this list!", Toast.LENGTH_LONG).show();
        } else {
            data.moveToFirst();
            theList.add("\nName" + "\t\t\t : " + data.getString(1) + "\nEMAIL" + "\t\t\t : " + data.getString(2) *//* "\n"
                    + "PASS" + "\t\t\t : " + data.getString(3) *//*+ "\nEMP_ID" + "\t\t\t : " + data.getString(4) + "\n"
                    + "OFFICE_ADDRESS" + "\t\t\t : " + data.getString(5) + "\nOFFICE_LAT" + "\t\t\t : " + data.getString(7) + "\n"
                    + "OFFICE_LNG" + "\t\t\t : " + data.getString(8)); *//*+ "\nOFFICE_LOC" + "\t\t\t : " + data.getString(8));*//*

                ListAdapter listAdapter = new ArrayAdapter<>(getActivity().getApplicationContext(), android.R.layout.simple_list_item_1, theList);
                listView.setCacheColorHint(Color.rgb(36, 33, 32));
                listView.setBackgroundColor(Color.rgb(192, 192, 192));
                listView.setAdapter(listAdapter);


        }*/
            //////////
        }




        return v;
}




  /*  private void populateData() {
        TableView tableview=n ew TableView();
        ArrayList<String> tablelist=new ArrayList<>();

        ListView listView = (ListView) v.findViewById(R.id.listView);
        ArrayList<String> theList = new ArrayList<>();

*/


/*
    private void populateData() {
        ArrayList<Spaceprobe> spaceprobeList=new ArrayList<>();
    }
*/


    @Override
            public void onClick(View v) {

                Intent i;
                switch (v.getId()) {
                    case R.id.button:
                        i = new Intent(getActivity(), Main2Activity.class);
                        getActivity().startActivity(i);
                        break;
              /*          break;
                    case R.id.camera:
                        i = new Intent(getActivity(), Camera.class);
                        getActivity().startActivity(i);
                        break;
*/

                    default:


                }

            }   /*switch(v.getId()){
            case R.id.btn1:
                Toast.makeText(getActivity(),"Button 1 clicked",Toast.LENGTH_SHORT).show();
                break;

            case R.id.btn2:
                Toast.makeText(getActivity(),"Button 2 clicked",Toast.LENGTH_SHORT).show();
                break;
        }*/



    private void logoutUser() {
       // session.setLogin(false);
        //db.deleteUsers();
       // db.deleteWorkplan();

        Fragment fragment = new LoginFragment();
        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame, fragment).commit();
    }
}
