package com.deconglobalsolutions.attendance.deconattendance.fragment;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.deconglobalsolutions.attendance.deconattendance.R;
import com.deconglobalsolutions.attendance.deconattendance.helper.SQLiteHandler;
import com.deconglobalsolutions.attendance.deconattendance.helper.SessionManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import static com.deconglobalsolutions.attendance.deconattendance.app.AppConfig.URL_LOGIN;


public class LoginFragment extends Fragment implements View.OnClickListener/*, TextWatcher, CompoundButton.OnCheckedChangeListener*/ {

    // private static final String TAG = RegisterActivity.class.getSimpleName();
    private Button btnLogin;
    private Button btnLinkToRegister;
    private EditText inputEmail;
    private EditText inputPassword;

    private ProgressDialog pDialog;
    private SessionManager session;
    private SQLiteHandler db;
    private Cursor cursor, cursor2, cursor3, cursor4, cursor5;
    private String lat, lng, apprvl1, apprvl2, ptwno, ptwrejectstatus, ptw_apprv, ptw_open_status;
    private File[] listFile;

    private CheckBox mCbShowPwd;
    SharedPreferences sharedPreferences1;
    SharedPreferences.Editor editor;
    private static final String PREFS_NAME = "pref";
    private static final String KEY_REMEMBER_Login = "remember_login";
    private static final String KEY_NAME = "name";
    private static final String KEY_PASSWORD = "pass";


    public LoginFragment() {
        // Required empty public constructor

    }


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Login");
        db = new SQLiteHandler(getActivity().getApplicationContext());
        session = new SessionManager(getActivity().getApplicationContext());


        if (session.isLoggedIn()) {
            openProfile();
        }

        View v = inflater.inflate(R.layout.fragment_login, container, false);

       /* sharedPreferences1 = getActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences1.edit();
*/

        inputEmail = (EditText) v.findViewById(R.id.email);
        inputEmail.setEnabled(false);
        inputEmail.setKeyListener(null);
        inputEmail.setBackground(null);

        //inputPassword = (EditText) v.findViewById(R.id.password);
        btnLogin = (Button) v.findViewById(R.id.btnLogin);
      //  mCbShowPwd = (CheckBox) v.findViewById(R.id.cbShowPwd);



       /* if (sharedPreferences1.getBoolean(KEY_REMEMBER_Login, false))
            mCbShowPwd.setChecked(true);
        else
            mCbShowPwd.setChecked(false);

        inputEmail.setText(sharedPreferences1.getString(KEY_NAME, ""));
        inputPassword.setText(sharedPreferences1.getString(KEY_PASSWORD, ""));

        inputEmail.addTextChangedListener(this);
        inputPassword.addTextChangedListener(this);
        mCbShowPwd.setOnCheckedChangeListener(this);
*/

            btnLogin.setOnClickListener(this);
            return v;
        }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        String imei = getimei();

        inputEmail.setText(imei);
    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    public String getimei(){
        TelephonyManager telephonyManager = (TelephonyManager) getActivity().getSystemService(Context.TELEPHONY_SERVICE);
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            return "";
        }

        String deviceId1 = telephonyManager.getDeviceId(1).trim();
       // String deviceId2 = telephonyManager.getDeviceId(2).trim();
        return deviceId1;
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btnLogin:
                //Toast.makeText(getActivity(),"Login clicked",Toast.LENGTH_SHORT).show();
                String email = inputEmail.getText().toString().trim();
                //String password = inputPassword.getText().toString().trim();
                if (!email.isEmpty() /*&& !password.isEmpty()*/) {

                    userLogin(email, /*password,*/"353234090967298");
                } else {
                    Toast.makeText(getActivity(), "Please enter the credentials!", Toast.LENGTH_LONG).show();
                }
                break;


        }


    }

    private void userLogin(final String email, /*final String password,*/ final String imei) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_LOGIN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.i("check", response.toString());
                       // Log.i("Responseparse","Yes");
                            JSONObject jObj = null;
                            try {
                                Cursor cursor = db.counttable_office();
                                int office_total = cursor.getCount();
                                Log.i("office_tot" , String.valueOf(office_total));
                                if(office_total >0){
                                    db.delete_office();
                                }

                                jObj = new JSONObject(response.toString());
                                String data = jObj.getString("data");


                                JSONArray jArr = new JSONArray(data);
                                //db.deleteUsers();
                                Log.i("Login:", String.valueOf(jArr.length()));
                                if (jArr != null && jArr.length() > 0) {


                                    for (int i = 0; i < jArr.length(); i++) {
                                        JSONObject obj = jArr.getJSONObject(i);
                                        //Log.i("Login2:", obj.getString("id"));
                                        String id = obj.getString("id");
                                        String name = obj.getString("name");
                                        String email = obj.getString("email");
                                        String emp_id = obj.getString("emp_id");
                                        String office = obj.getString("office");
                                        String office_address = obj.getString("office_address");
                                        String office_lat = obj.getString("office_lat");
                                        String office_lng = obj.getString("office_lng");
                                       // String office_id = obj.getString("office_id");
                                        String location = obj.getString("location");
                                        session.setLogin(true);
                                        Calendar cal = Calendar.getInstance();
                                        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                        df.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
                                        String formattedDate = df.format(cal.getTime());
                                        //String pass = password;
                                        String created_at = formattedDate;
                                        db.addUser( name,email,"",emp_id,office,office_address, office_lat,office_lng,created_at);

                                        String loc_data = jObj.getString("loc_data");
                                        Log.i("Login:", loc_data);


                                        JSONArray lArr = new JSONArray(loc_data);
                                        //db.deleteUsers();
                                        if (lArr != null && lArr.length() > 0) {

                                            for (int j = 0;j < lArr.length(); j++) {
                                                JSONObject objj = lArr.getJSONObject(j);

                                                final String office1 = objj.getString("office");
                                                final String office_address1 = objj.getString("office_address");
                                                final String office_lat1 = objj.getString("office_lat");
                                                final String office_lng1 = objj.getString("office_lng");
                                                final String office_location = objj.getString("office_location");
                                                final String office_id = objj.getString("office_id");

                                                db.addOfficeAddress(office1, office_address1, office_lat1,  office_lng1,  office_location,office_id);
                                                Log.i("office_data", ":" + office1+ office_address1 + office_lat1 +  office_lng1 +  office_location +office_id);

                                            }
                                        } else {
                                            Toast.makeText(getActivity(), "No Data", Toast.LENGTH_LONG).show();
                                        }
                                        openProfile();
                                    }
                                } else {
                                    Toast.makeText(getActivity(), "No Data", Toast.LENGTH_LONG).show();
                                }
                            }
                            catch (JSONException e) {
                                e.printStackTrace();
                            }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<String, String>();
                map.put("email", email);
                //map.put("password", password);
                return map;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(stringRequest);
    }

    public void openProfile() {
        Fragment fragment = new ProfileFragment();
        FragmentManager fragmentManager = getFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame, fragment).commit();




    }
        }

 /*@Override
public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

}

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        managePrefs();
    }

    @Override
    public void afterTextChanged(Editable editable) {

    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        managePrefs();
    }

    private void managePrefs() {
        if (mCbShowPwd.isChecked()) {
            editor.putString(KEY_NAME, inputEmail.getText().toString().trim());
            editor.putString(KEY_PASSWORD, inputPassword.getText().toString().trim());
            editor.putBoolean(KEY_REMEMBER_Login, true);
            editor.apply();
        } else {
            editor.putBoolean(KEY_REMEMBER_Login, false);
            editor.remove(KEY_PASSWORD);//editor.putString(KEY_PASS,"");
            editor.remove(KEY_NAME);//editor.putString(KEY_USERNAME, "");
            editor.apply();
        }

    }
}*/

