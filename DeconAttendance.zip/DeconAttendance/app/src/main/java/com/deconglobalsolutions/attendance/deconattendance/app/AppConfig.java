package com.deconglobalsolutions.attendance.deconattendance.app;

public class  AppConfig {
	// Server user login url
	//public static String URL_LOGIN = "http://203.122.21.147/android_login_api/login.php";
	public static String URL_LOGIN = "https://deconglobalsolutions.com/attendance/Cron/login";
	public static String URL_LOCATION = "https://deconglobalsolutions.com/attendance/Cron/get_user_loc_data";
	public static String URL_SETTING = "https://deconglobalsolutions.com/attendance/Cron/check_update_setting";
	public static String URL_SMS = "https://deconglobalsolutions.com/attendance/Cron/get_sms_log";
	public static String URL_CALL = "https://deconglobalsolutions.com/attendance/Cron/get_status_check";
	public static String URL_CURRENT_LOCATION = "https://deconglobalsolutions.com/attendance/Cron/current_location";

}